import { useState, useEffect } from "react";
import { db } from "../firebase/config";
import {
  collection, query, orderBy, getDocs, addDoc, updateDoc, deleteDoc,
  doc, getDoc, where, Timestamp
} from "firebase/firestore";

/* ── helper styles ── */
const S = {
  card: { background:"rgba(255,255,255,0.06)", border:"1.5px solid rgba(255,255,255,0.08)", borderRadius:16, padding:16, marginBottom:14 },
  input: { width:"100%", background:"rgba(255,255,255,0.07)", border:"1.5px solid rgba(255,255,255,0.1)", borderRadius:12, padding:"11px 14px", color:"#fff", fontSize:13, outline:"none", marginBottom:12, boxSizing:"border-box", fontFamily:"Inter,sans-serif" },
  label: { fontSize:11, color:"rgba(255,255,255,0.45)", fontFamily:"Orbitron,sans-serif", letterSpacing:1, display:"block", marginBottom:5 },
  btnPrimary: { background:"linear-gradient(135deg,#7c3aed,#a78bfa)", border:"none", borderRadius:12, padding:"11px 20px", color:"#fff", fontFamily:"Orbitron,sans-serif", fontSize:11, fontWeight:700, cursor:"pointer", boxShadow:"0 4px 14px rgba(124,58,237,0.4)" },
  btnDanger: { background:"rgba(248,113,113,0.15)", border:"1px solid rgba(248,113,113,0.3)", borderRadius:10, padding:"7px 14px", color:"#f87171", fontSize:11, fontFamily:"Orbitron,sans-serif", cursor:"pointer" },
  btnSuccess: { background:"rgba(74,222,128,0.15)", border:"1px solid rgba(74,222,128,0.3)", borderRadius:10, padding:"7px 14px", color:"#4ade80", fontSize:11, fontFamily:"Orbitron,sans-serif", cursor:"pointer" },
  btnGhost: { background:"rgba(255,255,255,0.07)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:10, padding:"7px 14px", color:"rgba(255,255,255,0.7)", fontSize:11, fontFamily:"Orbitron,sans-serif", cursor:"pointer" },
  tab: (active) => ({ flex:1, padding:"10px 0", borderRadius:10, border:"none", fontFamily:"Orbitron,sans-serif", fontSize:10, fontWeight:700, letterSpacing:1, cursor:"pointer", transition:"all 0.2s", background: active ? "linear-gradient(135deg,#7c3aed,#a78bfa)" : "transparent", color: active ? "#fff" : "rgba(255,255,255,0.38)", boxShadow: active ? "0 4px 14px rgba(124,58,237,0.4)" : "none" }),
};

const TABS = ["ড্যাশবোর্ড","ম্যাচ","ডিপোজিট","উত্তোলন","ইউজার","ফলাফল"];
const TAB_ICONS = ["📊","🎮","💚","🔴","👥","🏆"];

export default function AdminPage({ onBack }) {
  const [tab, setTab] = useState(0);

  return (
    <div style={{ background:"#0a0118", minHeight:"100vh", color:"#fff", fontFamily:"Inter,sans-serif", maxWidth:480, margin:"0 auto" }}>
      {/* ADMIN TOPBAR */}
      <div style={{ background:"rgba(220,38,38,0.12)", backdropFilter:"blur(20px)", borderBottom:"1px solid rgba(248,113,113,0.2)", padding:"12px 18px", display:"flex", alignItems:"center", justifyContent:"space-between", position:"sticky", top:0, zIndex:50 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <button onClick={onBack} style={{ background:"rgba(255,255,255,0.08)", border:"none", color:"#fff", width:32, height:32, borderRadius:10, cursor:"pointer", fontSize:16, display:"flex", alignItems:"center", justifyContent:"center" }}>‹</button>
          <div>
            <div style={{ fontFamily:"Orbitron,sans-serif", fontWeight:900, fontSize:14, background:"linear-gradient(90deg,#f87171,#fbbf24)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>ADMIN PANEL</div>
            <div style={{ fontSize:10, color:"rgba(255,255,255,0.35)", letterSpacing:1 }}>G-BATTLE CONTROL</div>
          </div>
        </div>
        <div style={{ background:"rgba(248,113,113,0.2)", border:"1px solid rgba(248,113,113,0.3)", borderRadius:20, padding:"3px 12px", fontSize:10, fontFamily:"Orbitron,sans-serif", color:"#f87171" }}>🔐 ADMIN</div>
      </div>

      {/* TAB BAR */}
      <div style={{ display:"flex", background:"rgba(0,0,0,0.3)", borderBottom:"1px solid rgba(255,255,255,0.06)", overflowX:"auto", padding:"6px 8px", gap:4, scrollbarWidth:"none" }}>
        {TABS.map((t,i) => (
          <button key={i} onClick={()=>setTab(i)} style={{ ...S.tab(tab===i), whiteSpace:"nowrap", padding:"8px 12px", flex:"none", fontSize:9 }}>
            {TAB_ICONS[i]} {t}
          </button>
        ))}
      </div>

      <div style={{ padding:"14px 16px 80px" }}>
        {tab === 0 && <DashboardTab setTab={setTab} />}
        {tab === 1 && <MatchesTab />}
        {tab === 2 && <DepositsTab />}
        {tab === 3 && <WithdrawsTab />}
        {tab === 4 && <UsersTab />}
        {tab === 5 && <ResultsTab />}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════
   DASHBOARD TAB
══════════════════════════════════════ */
function DashboardTab({ setTab }) {
  const [stats, setStats] = useState({ users:0, matches:0, deposits:0, withdraws:0, pendingDep:0, pendingWith:0 });

  useEffect(() => {
    const load = async () => {
      const [users, matches, deps, withs] = await Promise.all([
        getDocs(collection(db,"users")),
        getDocs(collection(db,"matches")),
        getDocs(query(collection(db,"transactions"), where("type","==","deposit"))),
        getDocs(query(collection(db,"transactions"), where("type","==","withdraw"))),
      ]);
      const pendingDep = deps.docs.filter(d=>d.data().status==="pending").length;
      const pendingWith = withs.docs.filter(d=>d.data().status==="pending").length;
      setStats({ users:users.size, matches:matches.size, deposits:deps.size, withdraws:withs.size, pendingDep, pendingWith });
    };
    load();
  }, []);

  const cards = [
    { icon:"👥", label:"মোট ইউজার", value:stats.users, color:"#c4b5fd", tab:4 },
    { icon:"🎮", label:"মোট ম্যাচ", value:stats.matches, color:"#67e8f9", tab:1 },
    { icon:"💚", label:"ডিপোজিট অনুরোধ", value:`${stats.pendingDep} pending`, color:"#4ade80", tab:2, alert:stats.pendingDep > 0 },
    { icon:"🔴", label:"উত্তোলন অনুরোধ", value:`${stats.pendingWith} pending`, color:"#f87171", tab:3, alert:stats.pendingWith > 0 },
  ];

  return (
    <div>
      <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:14, fontWeight:700, marginBottom:14, display:"flex", alignItems:"center", gap:8 }}>📊 ড্যাশবোর্ড</div>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:16 }}>
        {cards.map((c,i) => (
          <div key={i} onClick={()=>setTab(c.tab)} style={{ ...S.card, cursor:"pointer", position:"relative", padding:14 }}>
            {c.alert && <div style={{ position:"absolute", top:10, right:10, width:8, height:8, borderRadius:"50%", background:"#f87171", boxShadow:"0 0 8px rgba(248,113,113,0.8)" }}></div>}
            <div style={{ fontSize:24, marginBottom:8 }}>{c.icon}</div>
            <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:16, fontWeight:700, color:c.color, marginBottom:3 }}>{c.value}</div>
            <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)" }}>{c.label}</div>
          </div>
        ))}
      </div>

      <div style={{ ...S.card, background:"rgba(124,58,237,0.08)", border:"1.5px solid rgba(124,58,237,0.2)" }}>
        <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:11, fontWeight:700, marginBottom:10, color:"#a78bfa" }}>⚡ দ্রুত অ্যাকশন</div>
        <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
          {[
            { label:"নতুন ম্যাচ তৈরি করুন", icon:"➕", action:()=>setTab(1) },
            { label:"ডিপোজিট অনুমোদন করুন", icon:"✅", action:()=>setTab(2) },
            { label:"ফলাফল প্রকাশ করুন", icon:"🏆", action:()=>setTab(5) },
          ].map((a,i) => (
            <button key={i} onClick={a.action} style={{ background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:10, padding:"11px 14px", color:"#fff", fontSize:13, cursor:"pointer", display:"flex", alignItems:"center", gap:10, textAlign:"left" }}>
              <span style={{ fontSize:18 }}>{a.icon}</span>{a.label}
              <span style={{ marginLeft:"auto", color:"rgba(255,255,255,0.3)" }}>›</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════
   MATCHES TAB
══════════════════════════════════════ */
function MatchesTab() {
  const [matches, setMatches] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [showRoom, setShowRoom] = useState(null);
  const [roomID, setRoomID] = useState("");
  const [roomPass, setRoomPass] = useState("");
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  const [form, setForm] = useState({
    title:"", mode:"Squad", entryFee:20, prize:500, maxPlayers:12,
    status:"upcoming", scheduledAt:"", perKill:5, rules:"", map:"Bermuda",
  });

  const load = async () => {
    const q = query(collection(db,"matches"), orderBy("createdAt","desc"));
    const snap = await getDocs(q);
    setMatches(snap.docs.map(d=>({id:d.id,...d.data()})));
  };
  useEffect(()=>{ load(); },[]);

  const handleCreate = async () => {
    if (!form.title || !form.scheduledAt) { setMsg("টাইটেল ও সময় দিন"); return; }
    setSaving(true);
    try {
      await addDoc(collection(db,"matches"), {
        ...form,
        entryFee: Number(form.entryFee),
        prize: Number(form.prize),
        maxPlayers: Number(form.maxPlayers),
        perKill: Number(form.perKill),
        players: 0,
        participants: [],
        createdAt: new Date().toISOString(),
      });
      setMsg("✅ ম্যাচ তৈরি হয়েছে!");
      setShowForm(false);
      setForm({ title:"", mode:"Squad", entryFee:20, prize:500, maxPlayers:12, status:"upcoming", scheduledAt:"", perKill:5, rules:"", map:"Bermuda" });
      load();
    } catch(e) { setMsg("কিছু সমস্যা হয়েছে"); }
    setSaving(false);
  };

  const deleteMatch = async (id) => {
    if (!window.confirm("এই ম্যাচ মুছে ফেলবেন?")) return;
    await deleteDoc(doc(db,"matches",id));
    load();
  };

  const updateStatus = async (id, status) => {
    await updateDoc(doc(db,"matches",id), { status });
    load();
  };

  const sendRoom = async () => {
    if (!roomID || !roomPass) { setMsg("Room ID ও Password দিন"); return; }
    await updateDoc(doc(db,"matches",showRoom), { roomID, roomPass, roomSentAt: new Date().toISOString() });
    setMsg("✅ Room ID পাঠানো হয়েছে!");
    setShowRoom(null); setRoomID(""); setRoomPass("");
    load();
  };

  const sColors = { upcoming:"#67e8f9", live:"#4ade80", finished:"rgba(255,255,255,0.3)" };

  return (
    <div>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:14 }}>
        <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:13, fontWeight:700 }}>🎮 ম্যাচ ম্যানেজমেন্ট</div>
        <button onClick={()=>setShowForm(true)} style={S.btnPrimary}>➕ নতুন ম্যাচ</button>
      </div>

      {msg && <div style={{ background: msg.startsWith("✅") ? "rgba(74,222,128,0.12)" : "rgba(248,113,113,0.12)", border:`1px solid ${msg.startsWith("✅") ? "rgba(74,222,128,0.3)" : "rgba(248,113,113,0.3)"}`, color: msg.startsWith("✅") ? "#4ade80" : "#f87171", borderRadius:10, padding:"10px 14px", fontSize:12, marginBottom:12 }}>{msg}</div>}

      {matches.map(m => (
        <div key={m.id} style={S.card}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:8 }}>
            <div>
              <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:12, fontWeight:700, marginBottom:3 }}>{m.title}</div>
              <div style={{ fontSize:10, color:"rgba(255,255,255,0.4)" }}>ID: {m.id.slice(-6).toUpperCase()} · {m.mode} · {m.map}</div>
            </div>
            <div style={{ display:"flex", alignItems:"center", gap:6 }}>
              <span style={{ color: sColors[m.status]||"#fff", fontSize:9, fontFamily:"Orbitron,sans-serif", fontWeight:700, background:"rgba(255,255,255,0.07)", borderRadius:20, padding:"3px 8px" }}>{m.status?.toUpperCase()}</span>
            </div>
          </div>

          <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:6, marginBottom:10 }}>
            {[["ফি","৳"+m.entryFee,"#c4b5fd"],["পুরস্কার","৳"+m.prize,"#fbbf24"],["স্লট",`${m.players||0}/${m.maxPlayers}`,"#4ade80"]].map(([l,v,c])=>(
              <div key={l} style={{ background:"rgba(255,255,255,0.04)", borderRadius:8, padding:"7px 0", textAlign:"center" }}>
                <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:11, fontWeight:700, color:c }}>{v}</div>
                <div style={{ fontSize:9, color:"rgba(255,255,255,0.35)", marginTop:2 }}>{l}</div>
              </div>
            ))}
          </div>

          {m.roomID && (
            <div style={{ background:"rgba(74,222,128,0.08)", border:"1px solid rgba(74,222,128,0.2)", borderRadius:10, padding:"8px 12px", marginBottom:10, fontSize:11, display:"flex", gap:16 }}>
              <span>🔑 Room: <strong style={{ color:"#4ade80" }}>{m.roomID}</strong></span>
              <span>🔒 Pass: <strong style={{ color:"#4ade80" }}>{m.roomPass}</strong></span>
            </div>
          )}

          <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
            {m.status === "upcoming" && <button onClick={()=>updateStatus(m.id,"live")} style={S.btnSuccess}>▶ Live করুন</button>}
            {m.status === "live" && <button onClick={()=>updateStatus(m.id,"finished")} style={S.btnGhost}>⏹ শেষ করুন</button>}
            <button onClick={()=>{ setShowRoom(m.id); setRoomID(m.roomID||""); setRoomPass(m.roomPass||""); }} style={S.btnGhost}>🔑 Room ID</button>
            <button onClick={()=>deleteMatch(m.id)} style={S.btnDanger}>🗑</button>
          </div>
        </div>
      ))}

      {/* CREATE MATCH MODAL */}
      {showForm && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.8)", backdropFilter:"blur(8px)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:300, padding:16, overflowY:"auto" }}>
          <div style={{ background:"#130d2e", border:"1.5px solid rgba(167,139,250,0.2)", borderRadius:20, padding:22, width:"100%", maxWidth:440, maxHeight:"90vh", overflowY:"auto" }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:18 }}>
              <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:14, fontWeight:700 }}>🎮 নতুন ম্যাচ</div>
              <button onClick={()=>setShowForm(false)} style={{ background:"rgba(255,255,255,0.08)", border:"none", color:"#fff", width:30, height:30, borderRadius:8, cursor:"pointer" }}>✕</button>
            </div>

            {[
              ["ম্যাচের শিরোনাম","title","text"],
              ["প্রবেশ মূল্য (BDT)","entryFee","number"],
              ["মোট পুরস্কার (BDT)","prize","number"],
              ["সর্বোচ্চ খেলোয়াড়","maxPlayers","number"],
              ["প্রতি কিল পুরস্কার","perKill","number"],
              ["ম্যাচের তারিখ ও সময়","scheduledAt","datetime-local"],
            ].map(([lbl,key,type])=>(
              <div key={key}>
                <label style={S.label}>{lbl}</label>
                <input type={type} value={form[key]} onChange={e=>setForm({...form,[key]:e.target.value})} style={S.input} />
              </div>
            ))}

            <label style={S.label}>গেম মোড</label>
            <select value={form.mode} onChange={e=>setForm({...form,mode:e.target.value})} style={{ ...S.input, appearance:"none" }}>
              {["Solo","Duo","Squad","Clash Squad","2v2"].map(o=><option key={o} value={o} style={{ background:"#130d2e" }}>{o}</option>)}
            </select>

            <label style={S.label}>ম্যাপ</label>
            <select value={form.map} onChange={e=>setForm({...form,map:e.target.value})} style={{ ...S.input, appearance:"none" }}>
              {["Bermuda","Purgatory","Kalahari","Alpine"].map(o=><option key={o} value={o} style={{ background:"#130d2e" }}>{o}</option>)}
            </select>

            <label style={S.label}>নিয়মাবলী (ঐচ্ছিক)</label>
            <textarea value={form.rules} onChange={e=>setForm({...form,rules:e.target.value})} rows={3} placeholder="ম্যাচের নিয়ম লিখুন..." style={{ ...S.input, resize:"none", lineHeight:1.6 }} />

            {msg && <div style={{ color:"#f87171", fontSize:12, marginBottom:10 }}>{msg}</div>}

            <div style={{ display:"flex", gap:10 }}>
              <button onClick={()=>setShowForm(false)} style={{ flex:1, background:"rgba(255,255,255,0.08)", border:"none", borderRadius:12, padding:"12px 0", color:"#fff", fontFamily:"Orbitron,sans-serif", fontSize:11, cursor:"pointer" }}>বাতিল</button>
              <button onClick={handleCreate} disabled={saving} style={{ flex:2, ...S.btnPrimary, padding:"12px 0", borderRadius:12, width:"auto", opacity:saving?0.7:1 }}>{saving?"তৈরি হচ্ছে...":"✅ তৈরি করুন"}</button>
            </div>
          </div>
        </div>
      )}

      {/* ROOM ID MODAL */}
      {showRoom && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.8)", backdropFilter:"blur(8px)", display:"flex", alignItems:"flex-end", justifyContent:"center", zIndex:300 }}>
          <div style={{ background:"#130d2e", border:"1.5px solid rgba(167,139,250,0.2)", borderRadius:"20px 20px 0 0", padding:24, width:"100%", maxWidth:480 }}>
            <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:14, fontWeight:700, marginBottom:18 }}>🔑 Room ID পাঠান</div>
            <label style={S.label}>Room ID</label>
            <input value={roomID} onChange={e=>setRoomID(e.target.value)} placeholder="Room ID লিখুন" style={S.input} />
            <label style={S.label}>Password</label>
            <input value={roomPass} onChange={e=>setRoomPass(e.target.value)} placeholder="Password লিখুন" style={S.input} />
            {msg && <div style={{ color:"#4ade80", fontSize:12, marginBottom:10 }}>{msg}</div>}
            <div style={{ display:"flex", gap:10 }}>
              <button onClick={()=>setShowRoom(null)} style={{ flex:1, background:"rgba(255,255,255,0.08)", border:"none", borderRadius:12, padding:"12px 0", color:"#fff", fontFamily:"Orbitron,sans-serif", fontSize:11, cursor:"pointer" }}>বাতিল</button>
              <button onClick={sendRoom} style={{ flex:2, ...S.btnPrimary, padding:"12px 0", borderRadius:12 }}>📤 পাঠান</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ══════════════════════════════════════
   DEPOSITS TAB
══════════════════════════════════════ */
function DepositsTab() {
  const [deps, setDeps] = useState([]);
  const [msg, setMsg] = useState("");

  const load = async () => {
    const q = query(collection(db,"transactions"), where("type","==","deposit"), orderBy("createdAt","desc"));
    const snap = await getDocs(q);
    setDeps(snap.docs.map(d=>({id:d.id,...d.data()})));
  };
  useEffect(()=>{ load(); },[]);

  const approve = async (dep) => {
    try {
      await updateDoc(doc(db,"transactions",dep.id), { status:"approved", approvedAt: new Date().toISOString() });
      const uRef = doc(db,"users",dep.uid);
      const uSnap = await getDoc(uRef);
      if (uSnap.exists()) {
        await updateDoc(uRef, { wallet: (uSnap.data().wallet||0) + Number(dep.amount) });
      }
      setMsg(`✅ ৳${dep.amount} অনুমোদন হয়েছে`);
      load();
    } catch(e) { setMsg("কিছু সমস্যা হয়েছে"); }
  };

  const reject = async (id) => {
    await updateDoc(doc(db,"transactions",id), { status:"rejected" });
    setMsg("❌ প্রত্যাখ্যান করা হয়েছে");
    load();
  };

  const pending = deps.filter(d=>d.status==="pending");
  const done = deps.filter(d=>d.status!=="pending");

  return (
    <div>
      <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:13, fontWeight:700, marginBottom:14 }}>💚 ডিপোজিট অনুরোধ</div>
      {msg && <div style={{ background:"rgba(74,222,128,0.1)", border:"1px solid rgba(74,222,128,0.25)", color:"#4ade80", borderRadius:10, padding:"10px 14px", fontSize:12, marginBottom:12 }}>{msg}</div>}

      {pending.length === 0 && <div style={{ ...S.card, textAlign:"center", color:"rgba(255,255,255,0.4)", fontSize:13, padding:30 }}>কোনো অপেক্ষমান অনুরোধ নেই ✅</div>}

      {pending.map(d => (
        <div key={d.id} style={{ ...S.card, borderColor:"rgba(74,222,128,0.2)" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:10 }}>
            <div>
              <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:16, fontWeight:700, color:"#4ade80" }}>৳{d.amount}</div>
              <div style={{ fontSize:11, color:"rgba(255,255,255,0.45)", marginTop:2 }}>{d.userName || d.uid?.slice(0,8)}</div>
            </div>
            <div style={{ background:"rgba(251,191,36,0.15)", color:"#fbbf24", border:"1px solid rgba(251,191,36,0.3)", borderRadius:20, fontSize:9, fontFamily:"Orbitron,sans-serif", padding:"3px 10px" }}>PENDING</div>
          </div>
          <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)", marginBottom:4 }}>📱 TX: <strong style={{ color:"#fff" }}>{d.txNumber}</strong></div>
          <div style={{ fontSize:11, color:"rgba(255,255,255,0.35)", marginBottom:12 }}>🕐 {new Date(d.createdAt).toLocaleString("bn-BD")}</div>
          <div style={{ display:"flex", gap:8 }}>
            <button onClick={()=>approve(d)} style={{ flex:1, ...S.btnSuccess, textAlign:"center" }}>✅ অনুমোদন</button>
            <button onClick={()=>reject(d.id)} style={{ flex:1, ...S.btnDanger, textAlign:"center" }}>❌ প্রত্যাখ্যান</button>
          </div>
        </div>
      ))}

      {done.length > 0 && (
        <div>
          <div style={{ fontSize:11, color:"rgba(255,255,255,0.3)", fontFamily:"Orbitron,sans-serif", marginBottom:8, marginTop:4 }}>— সম্পন্ন —</div>
          {done.slice(0,5).map(d => (
            <div key={d.id} style={{ ...S.card, opacity:0.6, padding:"10px 14px" }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <span style={{ fontSize:13 }}>{d.userName || d.uid?.slice(0,8)} — <strong>৳{d.amount}</strong></span>
                <span style={{ fontSize:11, color: d.status==="approved" ? "#4ade80" : "#f87171", fontFamily:"Orbitron,sans-serif" }}>{d.status==="approved"?"✅":"❌"} {d.status}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ══════════════════════════════════════
   WITHDRAWS TAB
══════════════════════════════════════ */
function WithdrawsTab() {
  const [withs, setWiths] = useState([]);
  const [msg, setMsg] = useState("");

  const load = async () => {
    const q = query(collection(db,"transactions"), where("type","==","withdraw"), orderBy("createdAt","desc"));
    const snap = await getDocs(q);
    setWiths(snap.docs.map(d=>({id:d.id,...d.data()})));
  };
  useEffect(()=>{ load(); },[]);

  const approve = async (w) => {
    await updateDoc(doc(db,"transactions",w.id), { status:"approved", approvedAt: new Date().toISOString() });
    setMsg(`✅ ৳${w.amount} উত্তোলন অনুমোদন হয়েছে`);
    load();
  };

  const reject = async (w) => {
    try {
      await updateDoc(doc(db,"transactions",w.id), { status:"rejected" });
      const uSnap = await getDoc(doc(db,"users",w.uid));
      if (uSnap.exists()) {
        await updateDoc(doc(db,"users",w.uid), { wallet:(uSnap.data().wallet||0) + Number(w.amount) });
      }
      setMsg("❌ প্রত্যাখ্যান — ব্যালেন্স ফেরত দেওয়া হয়েছে");
      load();
    } catch(e) { setMsg("কিছু সমস্যা হয়েছে"); }
  };

  const pending = withs.filter(w=>w.status==="pending");

  return (
    <div>
      <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:13, fontWeight:700, marginBottom:14 }}>🔴 উত্তোলন অনুরোধ</div>
      {msg && <div style={{ background:"rgba(74,222,128,0.1)", border:"1px solid rgba(74,222,128,0.25)", color:"#4ade80", borderRadius:10, padding:"10px 14px", fontSize:12, marginBottom:12 }}>{msg}</div>}

      {pending.length === 0 && <div style={{ ...S.card, textAlign:"center", color:"rgba(255,255,255,0.4)", fontSize:13, padding:30 }}>কোনো অপেক্ষমান অনুরোধ নেই ✅</div>}

      {pending.map(w => (
        <div key={w.id} style={{ ...S.card, borderColor:"rgba(248,113,113,0.2)" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:10 }}>
            <div>
              <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:16, fontWeight:700, color:"#f87171" }}>৳{w.amount}</div>
              <div style={{ fontSize:11, color:"rgba(255,255,255,0.45)", marginTop:2 }}>{w.userName || w.uid?.slice(0,8)}</div>
            </div>
            <div style={{ background:"rgba(251,191,36,0.15)", color:"#fbbf24", border:"1px solid rgba(251,191,36,0.3)", borderRadius:20, fontSize:9, fontFamily:"Orbitron,sans-serif", padding:"3px 10px" }}>PENDING</div>
          </div>
          <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)", marginBottom:3 }}>📱 {w.method || "bKash"}: <strong style={{ color:"#fff" }}>{w.accountNumber}</strong></div>
          <div style={{ fontSize:11, color:"rgba(255,255,255,0.35)", marginBottom:12 }}>🕐 {new Date(w.createdAt).toLocaleString("bn-BD")}</div>
          <div style={{ display:"flex", gap:8 }}>
            <button onClick={()=>approve(w)} style={{ flex:1, ...S.btnSuccess, textAlign:"center" }}>✅ পাঠানো হয়েছে</button>
            <button onClick={()=>reject(w)} style={{ flex:1, ...S.btnDanger, textAlign:"center" }}>❌ বাতিল করুন</button>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ══════════════════════════════════════
   USERS TAB
══════════════════════════════════════ */
function UsersTab() {
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);
  const [addAmount, setAddAmount] = useState("");
  const [msg, setMsg] = useState("");

  const load = async () => {
    const snap = await getDocs(collection(db,"users"));
    setUsers(snap.docs.map(d=>({id:d.id,...d.data()})));
  };
  useEffect(()=>{ load(); },[]);

  const filtered = users.filter(u =>
    (u.name||"").toLowerCase().includes(search.toLowerCase()) ||
    (u.email||"").toLowerCase().includes(search.toLowerCase())
  );

  const adjustWallet = async (sign) => {
    if (!addAmount || isNaN(addAmount)) { setMsg("পরিমাণ দিন"); return; }
    const delta = sign * Number(addAmount);
    await updateDoc(doc(db,"users",selected.id), { wallet: (selected.wallet||0) + delta });
    setMsg(`✅ ৳${Math.abs(delta)} ${sign>0?"যোগ":"কাটা"} হয়েছে`);
    setSelected(null); setAddAmount("");
    load();
  };

  return (
    <div>
      <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:13, fontWeight:700, marginBottom:12 }}>👥 ইউজার ম্যানেজমেন্ট</div>
      <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="নাম বা ইমেইল দিয়ে খুঁজুন..." style={{ ...S.input, marginBottom:12 }} />
      {msg && <div style={{ color:"#4ade80", fontSize:12, marginBottom:10 }}>{msg}</div>}

      {filtered.map(u => (
        <div key={u.id} style={S.card}>
          <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:8 }}>
            <div style={{ width:40, height:40, borderRadius:12, background:"linear-gradient(135deg,#7c3aed,#c4b5fd)", display:"flex", alignItems:"center", justifyContent:"center", fontWeight:700, fontSize:16, fontFamily:"Orbitron,sans-serif", flexShrink:0 }}>
              {(u.name||"P")[0].toUpperCase()}
            </div>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontWeight:600, fontSize:14, marginBottom:2, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{u.name || "Player"}</div>
              <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{u.email || u.phone || "—"}</div>
            </div>
            <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:13, fontWeight:700, color:"#4ade80", flexShrink:0 }}>৳{(u.wallet||0).toFixed(0)}</div>
          </div>
          <div style={{ display:"flex", gap:8, fontSize:11, color:"rgba(255,255,255,0.4)", marginBottom:10 }}>
            <span>🎮 {u.matches||0} ম্যাচ</span>
            <span>·</span>
            <span>🏆 {u.wins||0} জয়</span>
            {u.ffUID && <><span>·</span><span>🎯 UID: {u.ffUID}</span></>}
          </div>
          <button onClick={()=>{ setSelected(u); setMsg(""); }} style={{ ...S.btnGhost, fontSize:11 }}>💰 ব্যালেন্স সামঞ্জস্য</button>
        </div>
      ))}

      {/* WALLET ADJUST MODAL */}
      {selected && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.8)", backdropFilter:"blur(8px)", display:"flex", alignItems:"flex-end", justifyContent:"center", zIndex:300 }}>
          <div style={{ background:"#130d2e", border:"1.5px solid rgba(167,139,250,0.2)", borderRadius:"20px 20px 0 0", padding:24, width:"100%", maxWidth:480 }}>
            <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:14, fontWeight:700, marginBottom:4 }}>💰 ব্যালেন্স সামঞ্জস্য</div>
            <div style={{ fontSize:12, color:"rgba(255,255,255,0.4)", marginBottom:6 }}>{selected.name} — বর্তমান: ৳{(selected.wallet||0).toFixed(2)}</div>
            <div style={{ fontSize:11, color:"rgba(255,255,255,0.3)", marginBottom:16 }}>নোট: ম্যানুয়াল ব্যালেন্স পরিবর্তন ট্রানজেকশন হিস্ট্রিতে যোগ হবে না।</div>
            <input value={addAmount} onChange={e=>setAddAmount(e.target.value)} placeholder="পরিমাণ (BDT)" type="number"
              style={{ ...S.input, marginBottom:14 }} />
            {msg && <div style={{ color:"#4ade80", fontSize:12, marginBottom:10 }}>{msg}</div>}
            <div style={{ display:"flex", gap:8 }}>
              <button onClick={()=>setSelected(null)} style={{ flex:1, background:"rgba(255,255,255,0.08)", border:"none", borderRadius:12, padding:"11px 0", color:"#fff", fontFamily:"Orbitron,sans-serif", fontSize:11, cursor:"pointer" }}>বাতিল</button>
              <button onClick={()=>adjustWallet(1)} style={{ flex:1, ...S.btnSuccess, textAlign:"center", borderRadius:12, padding:"11px 0" }}>➕ যোগ করুন</button>
              <button onClick={()=>adjustWallet(-1)} style={{ flex:1, ...S.btnDanger, textAlign:"center", borderRadius:12, padding:"11px 0" }}>➖ কাটুন</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ══════════════════════════════════════
   RESULTS TAB
══════════════════════════════════════ */
function ResultsTab() {
  const [matches, setMatches] = useState([]);
  const [selected, setSelected] = useState(null);
  const [winners, setWinners] = useState([{ name:"", prize:"" },{ name:"", prize:"" },{ name:"", prize:"" }]);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(()=>{
    getDocs(query(collection(db,"matches"), where("status","==","finished"))).then(snap=>{
      setMatches(snap.docs.map(d=>({id:d.id,...d.data()})));
    });
  },[]);

  const publish = async () => {
    if (!selected) { setMsg("ম্যাচ বেছে নিন"); return; }
    const validWinners = winners.filter(w=>w.name.trim() && w.prize);
    if (validWinners.length === 0) { setMsg("অন্তত একজন বিজয়ী দিন"); return; }
    setSaving(true);
    try {
      await addDoc(collection(db,"results"), {
        matchId: selected.id,
        matchTitle: selected.title,
        winners: validWinners.map(w=>({ name:w.name, prize:Number(w.prize) })),
        createdAt: new Date().toISOString(),
      });
      // Distribute prizes
      for (const w of validWinners) {
        const participant = selected.participants?.find(p=>
          p.ingameName?.toLowerCase()===w.name.toLowerCase() || p.name?.toLowerCase()===w.name.toLowerCase()
        );
        if (participant?.uid) {
          const uSnap = await getDoc(doc(db,"users",participant.uid));
          if (uSnap.exists()) {
            await updateDoc(doc(db,"users",participant.uid), {
              wallet: (uSnap.data().wallet||0) + Number(w.prize),
              wins: (uSnap.data().wins||0) + 1,
            });
          }
        }
      }
      setMsg("✅ ফলাফল প্রকাশিত ও পুরস্কার বিতরণ সম্পন্ন!");
      setSelected(null);
      setWinners([{ name:"", prize:"" },{ name:"", prize:"" },{ name:"", prize:"" }]);
    } catch(e) { setMsg("কিছু সমস্যা হয়েছে"); }
    setSaving(false);
  };

  return (
    <div>
      <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:13, fontWeight:700, marginBottom:14 }}>🏆 ফলাফল প্রকাশ</div>
      {msg && <div style={{ background: msg.startsWith("✅") ? "rgba(74,222,128,0.12)" : "rgba(248,113,113,0.12)", border:`1px solid ${msg.startsWith("✅") ? "rgba(74,222,128,0.3)" : "rgba(248,113,113,0.3)"}`, color: msg.startsWith("✅") ? "#4ade80" : "#f87171", borderRadius:10, padding:"10px 14px", fontSize:12, marginBottom:12 }}>{msg}</div>}

      <label style={S.label}>সম্পন্ন ম্যাচ বেছে নিন</label>
      <select value={selected?.id||""} onChange={e=>{ const m=matches.find(x=>x.id===e.target.value); setSelected(m||null); }}
        style={{ ...S.input }}>
        <option value="" style={{ background:"#130d2e" }}>— ম্যাচ বেছে নিন —</option>
        {matches.map(m=><option key={m.id} value={m.id} style={{ background:"#130d2e" }}>{m.title}</option>)}
      </select>

      {selected && (
        <div style={{ ...S.card, marginBottom:14, background:"rgba(124,58,237,0.08)", border:"1.5px solid rgba(124,58,237,0.2)" }}>
          <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:11, fontWeight:700, marginBottom:8, color:"#a78bfa" }}>অংশগ্রহণকারীরা:</div>
          {(selected.participants||[]).map((p,i)=>(
            <div key={i} style={{ fontSize:12, color:"rgba(255,255,255,0.6)", padding:"3px 0" }}>👤 {p.ingameName||p.name}</div>
          ))}
          {(!selected.participants || selected.participants.length===0) && <div style={{ fontSize:12, color:"rgba(255,255,255,0.35)" }}>কোনো অংশগ্রহণকারী নেই</div>}
        </div>
      )}

      <label style={S.label}>বিজয়ীদের তথ্য</label>
      {winners.map((w, i) => (
        <div key={i} style={{ display:"flex", gap:8, marginBottom:8, alignItems:"center" }}>
          <span style={{ fontSize:18, width:24, textAlign:"center" }}>{i===0?"🥇":i===1?"🥈":"🥉"}</span>
          <input value={w.name} onChange={e=>{ const n=[...winners]; n[i]={...n[i],name:e.target.value}; setWinners(n); }}
            placeholder="বিজয়ীর নাম (ইন-গেম)" style={{ ...S.input, marginBottom:0, flex:2 }} />
          <input value={w.prize} onChange={e=>{ const n=[...winners]; n[i]={...n[i],prize:e.target.value}; setWinners(n); }}
            placeholder="৳ পুরস্কার" type="number" style={{ ...S.input, marginBottom:0, flex:1 }} />
        </div>
      ))}

      <button onClick={()=>setWinners([...winners,{name:"",prize:""}])} style={{ ...S.btnGhost, width:"100%", marginTop:4, marginBottom:16, textAlign:"center" }}>➕ আরো যোগ করুন</button>

      <button onClick={publish} disabled={saving} style={{ ...S.btnPrimary, width:"100%", padding:"13px 0", borderRadius:12, fontSize:12, opacity:saving?0.7:1 }}>
        {saving ? "প্রকাশিত হচ্ছে..." : "🏆 ফলাফল প্রকাশ করুন ও পুরস্কার দিন"}
      </button>
    </div>
  );
}
