import { useAuth } from "../context/AuthContext";
import { useState, useEffect } from "react";
import { db } from "../firebase/config";
import { collection, query, orderBy, limit, getDocs } from "firebase/firestore";

const cats = [
  { id:"br", label:"BR MATCH", img:"🔫", color:"linear-gradient(135deg,#1e3a8a,#4c1d95)" },
  { id:"cs", label:"CLASH SQUAD", img:"⚔️", color:"linear-gradient(135deg,#065f46,#1e3a8a)" },
  { id:"cs2v2", label:"CLASH SQUAD 2V2", img:"🤝", color:"linear-gradient(135deg,#4c1d95,#7c2d12)" },
  { id:"lone", label:"LONE WOLF", img:"🐺", color:"linear-gradient(135deg,#7c2d12,#1e3a8a)" },
];

export default function HomePage({ onNavigate, onMatchClick }) {
  const { userData } = useAuth();
  const [matches, setMatches] = useState([]);

  useEffect(() => {
    const fetch = async () => {
      const q = query(collection(db, "matches"), orderBy("createdAt","desc"), limit(5));
      const snap = await getDocs(q);
      setMatches(snap.docs.map(d => ({ id:d.id, ...d.data() })));
    };
    fetch();
  }, []);

  return (
    <div style={{ padding:"16px 18px", position:"relative", overflow:"hidden" }}>
      {/* BG blobs */}
      <div style={{ position:"fixed", top:0, left:0, right:0, bottom:0, zIndex:-1, background:"#0a0118", overflow:"hidden" }}>
        <div style={{ position:"absolute", width:350, height:350, borderRadius:"50%", background:"radial-gradient(circle,#6d28d9,transparent)", top:-80, left:-60, opacity:0.3, filter:"blur(70px)", animation:"b1 14s ease-in-out infinite alternate" }}></div>
        <div style={{ position:"absolute", width:280, height:280, borderRadius:"50%", background:"radial-gradient(circle,#4c1d95,transparent)", bottom:100, right:-60, opacity:0.28, filter:"blur(60px)", animation:"b2 18s ease-in-out infinite alternate" }}></div>
        <div style={{ position:"absolute", inset:0, backgroundImage:"linear-gradient(rgba(255,255,255,0.025) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.025) 1px,transparent 1px)", backgroundSize:"36px 36px" }}></div>
      </div>
      <style>{`@keyframes b1{0%{transform:translate(0,0) scale(1)}100%{transform:translate(30px,-30px) scale(1.1)}} @keyframes b2{0%{transform:translate(0,0)}100%{transform:translate(-20px,30px) scale(0.93)}}`}</style>

      {/* WELCOME */}
      <div style={{ marginBottom:18 }}>
        <div style={{ fontSize:20, fontWeight:700, marginBottom:2 }}>স্বাগতম, {userData?.name?.split(" ")[0] || "Player"}! 👋</div>
        <div style={{ color:"rgba(255,255,255,0.4)", fontSize:13 }}>টুর্নামেন্ট খুঁজুন এবং যোগ দিন</div>
      </div>

      {/* BANNER */}
      <div style={{ background:"linear-gradient(135deg,#4c1d95,#7c3aed,#5b21b6)", borderRadius:18, padding:24, marginBottom:20, position:"relative", overflow:"hidden", border:"1.5px solid rgba(167,139,250,0.2)" }}>
        <div style={{ position:"absolute", top:-30, right:-20, fontSize:80, opacity:0.15 }}>🎮</div>
        <div style={{ position:"absolute", top:0, right:0, background:"rgba(74,222,128,0.2)", border:"1px solid rgba(74,222,128,0.4)", color:"#4ade80", fontSize:10, fontFamily:"Orbitron,sans-serif", fontWeight:700, padding:"4px 12px", borderRadius:"0 18px 0 12px", letterSpacing:1 }}>● LIVE</div>
        <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:11, color:"rgba(255,255,255,0.5)", letterSpacing:2, marginBottom:6, textTransform:"uppercase" }}>Featured Tournament</div>
        <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:22, fontWeight:900, marginBottom:4, lineHeight:1.2 }}>কিভাবে<br/><span style={{ color:"#c4b5fd" }}>TOURNAMENT</span><br/>খেলবেন?</div>
        <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)", marginBottom:16 }}>খেলুন, জিতুন, সেরা হন!</div>
        <button onClick={()=>onNavigate("matches")} style={{ background:"white", color:"#4c1d95", border:"none", borderRadius:10, padding:"9px 20px", fontFamily:"Orbitron,sans-serif", fontWeight:700, fontSize:11, cursor:"pointer", letterSpacing:1 }}>ম্যাচ দেখুন →</button>
      </div>

      {/* CATEGORIES */}
      <div style={{ marginBottom:8, fontFamily:"Orbitron,sans-serif", fontSize:13, fontWeight:700, letterSpacing:1, display:"flex", alignItems:"center", gap:8 }}>
        <span>⚡</span> ক্যাটাগরি
      </div>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:22 }}>
        {cats.map(c => (
          <div key={c.id} onClick={()=>onNavigate("matches")} style={{ background:c.color, borderRadius:16, overflow:"hidden", cursor:"pointer", border:"1.5px solid rgba(255,255,255,0.08)", transition:"transform 0.2s" }}
            onMouseEnter={e=>e.currentTarget.style.transform="scale(1.03)"} onMouseLeave={e=>e.currentTarget.style.transform="scale(1)"}>
            <div style={{ height:90, display:"flex", alignItems:"center", justifyContent:"center", fontSize:40, position:"relative" }}>
              {c.img}
              <div style={{ position:"absolute", bottom:0, left:0, right:0, background:"rgba(0,0,0,0.4)", padding:"6px 10px", fontFamily:"Orbitron,sans-serif", fontSize:10, fontWeight:700, letterSpacing:1 }}>{c.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* UPCOMING MATCHES */}
      <div style={{ marginBottom:12, fontFamily:"Orbitron,sans-serif", fontSize:13, fontWeight:700, letterSpacing:1, display:"flex", alignItems:"center", justifyContent:"space-between" }}>
        <span>🔥 আসন্ন ম্যাচ</span>
        <span onClick={()=>onNavigate("matches")} style={{ fontSize:11, color:"#a78bfa", cursor:"pointer" }}>সব দেখুন →</span>
      </div>

      {matches.length === 0 ? (
        <div style={{ background:"rgba(255,255,255,0.05)", borderRadius:14, padding:24, textAlign:"center", color:"rgba(255,255,255,0.35)", fontSize:13 }}>কোনো ম্যাচ নেই</div>
      ) : matches.map(m => (
        <div key={m.id} onClick={()=>onMatchClick(m)} style={{ background:"rgba(255,255,255,0.06)", border:"1.5px solid rgba(255,255,255,0.08)", borderRadius:16, padding:16, marginBottom:12, cursor:"pointer", transition:"all 0.2s" }}
          onMouseEnter={e=>e.currentTarget.style.borderColor="rgba(167,139,250,0.4)"} onMouseLeave={e=>e.currentTarget.style.borderColor="rgba(255,255,255,0.08)"}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:10 }}>
            <div>
              <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:12, fontWeight:700, marginBottom:4 }}>{m.title || "Match"}</div>
              <div style={{ fontSize:10, color:"rgba(255,255,255,0.4)" }}>ID: {m.id?.slice(-6).toUpperCase()}</div>
            </div>
            <div style={{ background: m.status==="live" ? "rgba(74,222,128,0.15)" : m.status==="upcoming" ? "rgba(103,232,249,0.15)" : "rgba(251,191,36,0.15)", color: m.status==="live" ? "#4ade80" : m.status==="upcoming" ? "#67e8f9" : "#fbbf24", border:`1px solid ${m.status==="live" ? "rgba(74,222,128,0.3)" : "rgba(103,232,249,0.3)"}`, borderRadius:20, fontSize:9, fontFamily:"Orbitron,sans-serif", fontWeight:700, padding:"3px 10px", letterSpacing:1 }}>
              {m.status === "live" ? "● LIVE" : m.status === "upcoming" ? "UPCOMING" : "REG OPEN"}
            </div>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:8 }}>
            {[["প্রবেশ মূল্য", `৳${m.entryFee || 0}`], ["পুরস্কার", `৳${m.prize || 0}`], ["খেলোয়াড়", `${m.players || 0}/${m.maxPlayers || 0}`], ["মোড", m.mode || "Squad"]].map(([l,v]) => (
              <div key={l} style={{ textAlign:"center" }}>
                <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:11, fontWeight:700, color:"#c4b5fd" }}>{v}</div>
                <div style={{ fontSize:9, color:"rgba(255,255,255,0.38)", textTransform:"uppercase", marginTop:2 }}>{l}</div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
