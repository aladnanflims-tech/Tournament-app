import { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";

const S = {
  page: { minHeight:"100vh", background:"#0a0118", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:24, position:"relative", overflow:"hidden" },
  blob1: { position:"absolute", width:400, height:400, borderRadius:"50%", background:"radial-gradient(circle,#6d28d9,transparent)", top:-100, left:-100, opacity:0.4, filter:"blur(80px)", animation:"bm1 12s ease-in-out infinite alternate" },
  blob2: { position:"absolute", width:300, height:300, borderRadius:"50%", background:"radial-gradient(circle,#4c1d95,transparent)", bottom:-80, right:-80, opacity:0.35, filter:"blur(70px)", animation:"bm2 15s ease-in-out infinite alternate" },
  logo: { fontFamily:"Orbitron,sans-serif", fontSize:36, fontWeight:900, background:"linear-gradient(135deg,#a78bfa,#fff,#c4b5fd)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent", marginBottom:4, letterSpacing:3, textShadow:"0 0 40px rgba(167,139,250,0.5)" },
  sub: { color:"rgba(255,255,255,0.4)", fontSize:12, fontFamily:"Orbitron,sans-serif", letterSpacing:2, marginBottom:36, textTransform:"uppercase" },
  card: { background:"rgba(255,255,255,0.06)", backdropFilter:"blur(24px)", border:"1.5px solid rgba(255,255,255,0.1)", borderRadius:20, padding:28, width:"100%", maxWidth:380, position:"relative", zIndex:1 },
  tabs: { display:"flex", background:"rgba(0,0,0,0.3)", borderRadius:12, padding:4, marginBottom:24, gap:4 },
  tab: (active) => ({ flex:1, padding:"9px 0", borderRadius:9, border:"none", fontFamily:"Orbitron,sans-serif", fontSize:10, fontWeight:700, letterSpacing:1, cursor:"pointer", transition:"all 0.2s", background: active ? "linear-gradient(135deg,#7c3aed,#a78bfa)" : "transparent", color: active ? "#fff" : "rgba(255,255,255,0.4)", boxShadow: active ? "0 4px 14px rgba(124,58,237,0.4)" : "none" }),
  input: { width:"100%", background:"rgba(255,255,255,0.07)", border:"1.5px solid rgba(255,255,255,0.1)", borderRadius:12, padding:"12px 16px", color:"#fff", fontSize:14, outline:"none", marginBottom:12, fontFamily:"Inter,sans-serif", boxSizing:"border-box" },
  btnPrimary: { width:"100%", background:"linear-gradient(135deg,#7c3aed,#a78bfa)", color:"#fff", border:"none", borderRadius:12, padding:"13px 0", fontFamily:"Orbitron,sans-serif", fontWeight:700, fontSize:12, letterSpacing:1, cursor:"pointer", marginBottom:12, boxShadow:"0 6px 20px rgba(124,58,237,0.4)", transition:"all 0.2s" },
  btnGoogle: { width:"100%", background:"rgba(255,255,255,0.09)", color:"#fff", border:"1.5px solid rgba(255,255,255,0.15)", borderRadius:12, padding:"12px 0", fontFamily:"Inter,sans-serif", fontWeight:600, fontSize:13, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:10, marginBottom:12, transition:"all 0.2s" },
  divider: { display:"flex", alignItems:"center", gap:12, margin:"16px 0" },
  divLine: { flex:1, height:1, background:"rgba(255,255,255,0.1)" },
  divText: { color:"rgba(255,255,255,0.35)", fontSize:11 },
  err: { background:"rgba(248,113,113,0.15)", border:"1px solid rgba(248,113,113,0.3)", color:"#f87171", borderRadius:10, padding:"10px 14px", fontSize:12, marginBottom:12, textAlign:"center" },
  otpRow: { display:"flex", gap:8, marginBottom:12 },
};

export default function LoginPage() {
  const { loginGoogle, loginEmail, registerEmail, setupRecaptcha, sendOTP } = useAuth();
  const [tab, setTab] = useState("email"); // email | phone
  const [mode, setMode] = useState("login"); // login | register
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [confirmResult, setConfirmResult] = useState(null);
  const [otpSent, setOtpSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => {
    setupRecaptcha("recaptcha-container");
  }, []);

  const handleGoogle = async () => {
    setErr(""); setLoading(true);
    try { await loginGoogle(); }
    catch(e) { setErr("Google লগইন ব্যর্থ হয়েছে"); }
    setLoading(false);
  };

  const handleEmail = async () => {
    setErr(""); setLoading(true);
    try {
      if (mode === "login") await loginEmail(email, pass);
      else await registerEmail(email, pass, name);
    } catch(e) {
      if (e.code === "auth/user-not-found") setErr("ইউজার পাওয়া যায়নি");
      else if (e.code === "auth/wrong-password") setErr("পাসওয়ার্ড ভুল");
      else if (e.code === "auth/email-already-in-use") setErr("ইমেইল আগে থেকেই আছে");
      else setErr("কিছু একটা সমস্যা হয়েছে");
    }
    setLoading(false);
  };

  const handleSendOTP = async () => {
    setErr(""); setLoading(true);
    try {
      const ph = phone.startsWith("+") ? phone : "+88" + phone;
      const result = await sendOTP(ph);
      setConfirmResult(result);
      setOtpSent(true);
    } catch(e) { setErr("OTP পাঠানো যায়নি। নম্বর চেক করুন।"); }
    setLoading(false);
  };

  const handleVerifyOTP = async () => {
    setErr(""); setLoading(true);
    try { await confirmResult.confirm(otp); }
    catch(e) { setErr("OTP ভুল হয়েছে"); }
    setLoading(false);
  };

  return (
    <div style={S.page}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@700;900&family=Inter:wght@400;500;600&display=swap');
        @keyframes bm1{0%{transform:translate(0,0) scale(1)}100%{transform:translate(30px,-40px) scale(1.1)}}
        @keyframes bm2{0%{transform:translate(0,0) scale(1)}100%{transform:translate(-30px,30px) scale(0.92)}}
        input::placeholder{color:rgba(255,255,255,0.28)}
        input:focus{border-color:rgba(167,139,250,0.5)!important}
      `}</style>
      <div style={S.blob1}></div>
      <div style={S.blob2}></div>
      <div id="recaptcha-container"></div>

      <div style={S.logo}>G-BATTLE</div>
      <div style={S.sub}>Free Fire Tournament Platform</div>

      <div style={S.card}>
        {/* MODE TABS */}
        <div style={S.tabs}>
          <button style={S.tab(mode==="login")} onClick={()=>setMode("login")}>লগইন</button>
          <button style={S.tab(mode==="register")} onClick={()=>setMode("register")}>রেজিস্টার</button>
        </div>

        {err && <div style={S.err}>{err}</div>}

        {/* GOOGLE */}
        <button style={S.btnGoogle} onClick={handleGoogle} disabled={loading}>
          <svg width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
          Google দিয়ে {mode === "login" ? "লগইন" : "রেজিস্টার"}
        </button>

        <div style={S.divider}>
          <div style={S.divLine}></div>
          <div style={S.divText}>অথবা</div>
          <div style={S.divLine}></div>
        </div>

        {/* METHOD TABS */}
        <div style={{...S.tabs, marginBottom:16}}>
          <button style={S.tab(tab==="email")} onClick={()=>setTab("email")}>ইমেইল</button>
          <button style={S.tab(tab==="phone")} onClick={()=>setTab("phone")}>ফোন OTP</button>
        </div>

        {tab === "email" && <>
          {mode === "register" && <input style={S.input} placeholder="আপনার নাম" value={name} onChange={e=>setName(e.target.value)} />}
          <input style={S.input} placeholder="ইমেইল" type="email" value={email} onChange={e=>setEmail(e.target.value)} />
          <input style={S.input} placeholder="পাসওয়ার্ড" type="password" value={pass} onChange={e=>setPass(e.target.value)} />
          <button style={S.btnPrimary} onClick={handleEmail} disabled={loading}>
            {loading ? "অপেক্ষা করুন..." : mode === "login" ? "লগইন করুন" : "রেজিস্টার করুন"}
          </button>
        </>}

        {tab === "phone" && <>
          {!otpSent ? <>
            <div style={S.otpRow}>
              <input style={{...S.input, width:70, marginBottom:0, textAlign:"center"}} value="+880" readOnly />
              <input style={{...S.input, flex:1, marginBottom:0}} placeholder="01XXXXXXXXX" value={phone} onChange={e=>setPhone(e.target.value)} />
            </div>
            <div style={{height:12}}></div>
            <button style={S.btnPrimary} onClick={handleSendOTP} disabled={loading}>
              {loading ? "পাঠানো হচ্ছে..." : "OTP পাঠান"}
            </button>
          </> : <>
            <input style={S.input} placeholder="6 সংখ্যার OTP" value={otp} onChange={e=>setOtp(e.target.value)} maxLength={6} />
            <button style={S.btnPrimary} onClick={handleVerifyOTP} disabled={loading}>
              {loading ? "যাচাই হচ্ছে..." : "যাচাই করুন"}
            </button>
            <button onClick={()=>setOtpSent(false)} style={{background:"none",border:"none",color:"rgba(255,255,255,0.4)",fontSize:12,cursor:"pointer",width:"100%",textAlign:"center"}}>← ফিরে যান</button>
          </>}
        </>}
      </div>
    </div>
  );
}
