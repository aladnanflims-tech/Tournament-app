import { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { db } from "../firebase/config";
import { collection, query, where, orderBy, getDocs, addDoc, updateDoc, doc } from "firebase/firestore";

export default function WalletPage() {
  const { user, userData } = useAuth();
  const [transactions, setTransactions] = useState([]);
  const [modal, setModal] = useState(null); // "deposit" | "withdraw"
  const [amount, setAmount] = useState("");
  const [txNumber, setTxNumber] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [method, setMethod] = useState("bKash");
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);

  const load = async () => {
    if (!user) return;
    const q = query(collection(db,"transactions"), where("uid","==",user.uid), orderBy("createdAt","desc"));
    const snap = await getDocs(q);
    setTransactions(snap.docs.map(d=>({id:d.id,...d.data()})));
  };

  useEffect(()=>{ load(); },[user]);

  const handleDeposit = async () => {
    if (!amount || !txNumber) { setMsg("সব তথ্য পূরণ করুন"); return; }
    if (Number(amount) < 10) { setMsg("সর্বনিম্ন ডিপোজিট ৳১০"); return; }
    setLoading(true);
    try {
      await addDoc(collection(db,"transactions"), {
        uid: user.uid,
        userName: userData?.name || "Player",
        type: "deposit",
        amount: Number(amount),
        txNumber,
        status: "pending",
        createdAt: new Date().toISOString(),
      });
      setMsg("✅ ডিপোজিট রিকোয়েস্ট পাঠানো হয়েছে! অ্যাডমিন যাচাই করার পর ব্যালেন্স যোগ হবে।");
      setModal(null); setAmount(""); setTxNumber("");
      load();
    } catch(e) { setMsg("কিছু সমস্যা হয়েছে"); }
    setLoading(false);
  };

  const handleWithdraw = async () => {
    if (!amount || !accountNumber) { setMsg("সব তথ্য পূরণ করুন"); return; }
    if (Number(amount) < 50) { setMsg("সর্বনিম্ন উত্তোলন ৳৫০"); return; }
    if ((userData?.wallet || 0) < Number(amount)) { setMsg("পর্যাপ্ত ব্যালেন্স নেই"); return; }
    setLoading(true);
    try {
      // Deduct from wallet immediately (hold)
      await updateDoc(doc(db,"users",user.uid), { wallet: (userData.wallet||0) - Number(amount) });
      await addDoc(collection(db,"transactions"), {
        uid: user.uid,
        userName: userData?.name || "Player",
        type: "withdraw",
        amount: Number(amount),
        accountNumber,
        method,
        status: "pending",
        createdAt: new Date().toISOString(),
      });
      setMsg("✅ উত্তোলন রিকোয়েস্ট পাঠানো হয়েছে! অ্যাডমিন প্রক্রিয়া করবেন।");
      setModal(null); setAmount(""); setAccountNumber("");
      load();
    } catch(e) { setMsg("কিছু সমস্যা হয়েছে"); }
    setLoading(false);
  };

  const txIcon = (t) => t.type==="deposit" ? "💚" : t.type==="withdraw" ? "🔴" : "🔵";
  const txLabel = (t) => t.type==="deposit" ? "জমা" : t.type==="withdraw" ? "উত্তোলন" : "ম্যাচ ফি";
  const txColor = (t) => t.type==="deposit" ? "#4ade80" : "#f87171";
  const txSign = (t) => t.type==="deposit" ? "+" : "-";
  const statusBadge = (s) => ({ pending:"⏳", approved:"✅", rejected:"❌" }[s] || "");

  return (
    <div style={{ padding:"16px 18px" }}>
      <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:16, fontWeight:700, marginBottom:16 }}>💰 আমার ওয়ালেট</div>

      {/* BALANCE CARD */}
      <div style={{ background:"linear-gradient(135deg,#4c1d95,#7c3aed,#5b21b6)", borderRadius:20, padding:28, marginBottom:16, textAlign:"center", border:"1.5px solid rgba(167,139,250,0.2)", boxShadow:"0 10px 40px rgba(124,58,237,0.3)" }}>
        <div style={{ fontSize:11, color:"rgba(255,255,255,0.5)", fontFamily:"Orbitron,sans-serif", letterSpacing:2, marginBottom:8 }}>মোট ব্যালেন্স</div>
        <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:44, fontWeight:900, marginBottom:4, textShadow:"0 0 30px rgba(196,181,253,0.4)" }}>{(userData?.wallet || 0).toFixed(2)}</div>
        <div style={{ fontSize:14, color:"rgba(255,255,255,0.5)", fontFamily:"Orbitron,sans-serif", letterSpacing:2, marginBottom:22 }}>BDT</div>
        <div style={{ display:"flex", gap:10 }}>
          {[["➕","জমা",()=>{ setModal("deposit"); setMsg(""); }],["➖","তুলুন",()=>{ setModal("withdraw"); setMsg(""); }],["📊","হিস্ট্রি",()=>{}]].map(([icon,label,fn]) => (
            <button key={label} onClick={fn} style={{ flex:1, background:"rgba(255,255,255,0.12)", border:"1.5px solid rgba(255,255,255,0.18)", borderRadius:12, padding:"10px 0", color:"#fff", fontSize:11, fontFamily:"Orbitron,sans-serif", fontWeight:700, cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:4 }}>
              <span style={{ fontSize:16 }}>{icon}</span>{label}
            </button>
          ))}
        </div>
      </div>

      {/* AI TOPUP */}
      <div style={{ background:"rgba(255,255,255,0.06)", border:"1.5px solid rgba(255,255,255,0.08)", borderRadius:16, padding:16, marginBottom:16, display:"flex", alignItems:"center", gap:14, cursor:"pointer" }}>
        <div style={{ width:46, height:46, borderRadius:14, background:"linear-gradient(135deg,#7c3aed,#a78bfa)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:22, flexShrink:0 }}>💎</div>
        <div style={{ flex:1 }}>
          <div style={{ fontWeight:700, fontSize:12, color:"#c4b5fd", fontFamily:"Orbitron,sans-serif" }}>AI Topup</div>
          <div style={{ fontSize:12, color:"rgba(255,255,255,0.4)", marginTop:2 }}>Free Fire Diamond Recharge</div>
        </div>
        <div style={{ color:"rgba(255,255,255,0.3)", fontSize:18 }}>›</div>
      </div>

      {msg && <div style={{ background: msg.startsWith("✅") ? "rgba(74,222,128,0.1)" : "rgba(248,113,113,0.1)", border:`1px solid ${msg.startsWith("✅") ? "rgba(74,222,128,0.25)" : "rgba(248,113,113,0.25)"}`, color: msg.startsWith("✅") ? "#4ade80" : "#f87171", borderRadius:12, padding:"12px 16px", fontSize:12, marginBottom:16 }}>{msg}</div>}

      {/* TRANSACTIONS */}
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:12 }}>
        <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:12, fontWeight:700 }}>💳 লেনদেনের ইতিহাস</div>
      </div>

      <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:14, overflow:"hidden" }}>
        {transactions.length === 0 ? (
          <div style={{ textAlign:"center", color:"rgba(255,255,255,0.3)", fontSize:13, padding:"24px 0" }}>কোনো লেনদেন নেই</div>
        ) : transactions.map(t => (
          <div key={t.id} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"12px 16px", borderBottom:"1px solid rgba(255,255,255,0.05)" }}>
            <div style={{ display:"flex", alignItems:"center", gap:10 }}>
              <div style={{ width:36, height:36, borderRadius:10, background: t.type==="deposit" ? "rgba(74,222,128,0.12)" : "rgba(248,113,113,0.12)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:16 }}>{txIcon(t)}</div>
              <div>
                <div style={{ fontSize:13, fontWeight:500 }}>{txLabel(t)} {statusBadge(t.status)}</div>
                <div style={{ fontSize:10, color:"rgba(255,255,255,0.35)", marginTop:1 }}>{new Date(t.createdAt).toLocaleDateString("bn-BD")}</div>
              </div>
            </div>
            <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:13, fontWeight:700, color:txColor(t) }}>
              {txSign(t)}৳{t.amount}
            </div>
          </div>
        ))}
      </div>

      {/* DEPOSIT MODAL */}
      {modal === "deposit" && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.75)", backdropFilter:"blur(8px)", display:"flex", alignItems:"flex-end", justifyContent:"center", zIndex:200 }}>
          <div style={{ background:"#130d2e", border:"1.5px solid rgba(167,139,250,0.2)", borderRadius:"20px 20px 0 0", padding:24, width:"100%", maxWidth:480 }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
              <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:14, fontWeight:700 }}>💰 ব্যালেন্স জমা দিন</div>
              <button onClick={()=>setModal(null)} style={{ background:"rgba(255,255,255,0.08)", border:"none", color:"#fff", width:30, height:30, borderRadius:8, cursor:"pointer" }}>✕</button>
            </div>
            <div style={{ fontSize:12, color:"rgba(255,255,255,0.4)", marginBottom:16 }}>bKash/Nagad এ পাঠিয়ে নিচে তথ্য দিন</div>
            <div style={{ background:"rgba(167,139,250,0.08)", border:"1px solid rgba(167,139,250,0.2)", borderRadius:12, padding:14, marginBottom:16, fontSize:12 }}>
              <div style={{ marginBottom:6 }}>📱 bKash: <strong>01XXXXXXXXX</strong></div>
              <div>📱 Nagad: <strong>01XXXXXXXXX</strong></div>
            </div>
            <input value={amount} onChange={e=>setAmount(e.target.value)} placeholder="পরিমাণ (BDT) — সর্বনিম্ন ৳১০" type="number"
              style={{ width:"100%", background:"rgba(255,255,255,0.07)", border:"1.5px solid rgba(255,255,255,0.1)", borderRadius:12, padding:"11px 14px", color:"#fff", fontSize:13, outline:"none", marginBottom:10, boxSizing:"border-box" }} />
            <input value={txNumber} onChange={e=>setTxNumber(e.target.value)} placeholder="ট্রানজেকশন নম্বর"
              style={{ width:"100%", background:"rgba(255,255,255,0.07)", border:"1.5px solid rgba(255,255,255,0.1)", borderRadius:12, padding:"11px 14px", color:"#fff", fontSize:13, outline:"none", marginBottom:16, boxSizing:"border-box" }} />
            {msg && <div style={{ color:"#f87171", fontSize:12, marginBottom:10 }}>{msg}</div>}
            <div style={{ display:"flex", gap:10 }}>
              <button onClick={()=>setModal(null)} style={{ flex:1, background:"rgba(255,255,255,0.08)", border:"none", borderRadius:12, padding:"12px 0", color:"#fff", fontFamily:"Orbitron,sans-serif", fontSize:11, cursor:"pointer" }}>বাতিল</button>
              <button onClick={handleDeposit} disabled={loading} style={{ flex:2, background:"linear-gradient(135deg,#7c3aed,#a78bfa)", border:"none", borderRadius:12, padding:"12px 0", color:"#fff", fontFamily:"Orbitron,sans-serif", fontSize:11, fontWeight:700, cursor:"pointer", opacity:loading?0.7:1 }}>{loading?"পাঠানো হচ্ছে...":"সাবমিট করুন"}</button>
            </div>
          </div>
        </div>
      )}

      {/* WITHDRAW MODAL */}
      {modal === "withdraw" && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.75)", backdropFilter:"blur(8px)", display:"flex", alignItems:"flex-end", justifyContent:"center", zIndex:200 }}>
          <div style={{ background:"#130d2e", border:"1.5px solid rgba(248,113,113,0.2)", borderRadius:"20px 20px 0 0", padding:24, width:"100%", maxWidth:480 }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
              <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:14, fontWeight:700 }}>💸 ব্যালেন্স তুলুন</div>
              <button onClick={()=>setModal(null)} style={{ background:"rgba(255,255,255,0.08)", border:"none", color:"#fff", width:30, height:30, borderRadius:8, cursor:"pointer" }}>✕</button>
            </div>
            <div style={{ fontSize:12, color:"rgba(255,255,255,0.4)", marginBottom:16 }}>বর্তমান ব্যালেন্স: <strong style={{ color:"#4ade80" }}>৳{(userData?.wallet||0).toFixed(2)}</strong> — সর্বনিম্ন ৳৫০</div>

            <div style={{ display:"flex", gap:8, marginBottom:12 }}>
              {["bKash","Nagad","Rocket"].map(m=>(
                <button key={m} onClick={()=>setMethod(m)} style={{ flex:1, background: method===m ? "rgba(167,139,250,0.2)" : "rgba(255,255,255,0.06)", border:`1.5px solid ${method===m ? "rgba(167,139,250,0.5)" : "rgba(255,255,255,0.1)"}`, borderRadius:10, padding:"8px 0", color: method===m ? "#c4b5fd" : "rgba(255,255,255,0.6)", fontSize:11, fontFamily:"Orbitron,sans-serif", cursor:"pointer" }}>{m}</button>
              ))}
            </div>

            <input value={amount} onChange={e=>setAmount(e.target.value)} placeholder="পরিমাণ (BDT)" type="number"
              style={{ width:"100%", background:"rgba(255,255,255,0.07)", border:"1.5px solid rgba(255,255,255,0.1)", borderRadius:12, padding:"11px 14px", color:"#fff", fontSize:13, outline:"none", marginBottom:10, boxSizing:"border-box" }} />
            <input value={accountNumber} onChange={e=>setAccountNumber(e.target.value)} placeholder={`${method} নম্বর (01XXXXXXXXX)`}
              style={{ width:"100%", background:"rgba(255,255,255,0.07)", border:"1.5px solid rgba(255,255,255,0.1)", borderRadius:12, padding:"11px 14px", color:"#fff", fontSize:13, outline:"none", marginBottom:16, boxSizing:"border-box" }} />
            {msg && <div style={{ color:"#f87171", fontSize:12, marginBottom:10 }}>{msg}</div>}
            <div style={{ display:"flex", gap:10 }}>
              <button onClick={()=>setModal(null)} style={{ flex:1, background:"rgba(255,255,255,0.08)", border:"none", borderRadius:12, padding:"12px 0", color:"#fff", fontFamily:"Orbitron,sans-serif", fontSize:11, cursor:"pointer" }}>বাতিল</button>
              <button onClick={handleWithdraw} disabled={loading} style={{ flex:2, background:"linear-gradient(135deg,#dc2626,#f87171)", border:"none", borderRadius:12, padding:"12px 0", color:"#fff", fontFamily:"Orbitron,sans-serif", fontSize:11, fontWeight:700, cursor:"pointer", opacity:loading?0.7:1 }}>{loading?"প্রসেস হচ্ছে...":"উত্তোলন করুন"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
