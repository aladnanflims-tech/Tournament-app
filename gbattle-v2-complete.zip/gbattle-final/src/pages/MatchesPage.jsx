import { useState, useEffect } from "react";
import { db } from "../firebase/config";
import { collection, query, orderBy, getDocs } from "firebase/firestore";

const modes = ["সব", "BR Match", "Clash Squad", "2V2", "Lone Wolf"];

export default function MatchesPage({ onMatchClick }) {
  const [matches, setMatches] = useState([]);
  const [filter, setFilter] = useState("সব");
  const [loading, setLoading] = useState(true);

  const fetchMatches = async () => {
    setLoading(true);
    const q = query(collection(db, "matches"), orderBy("createdAt","desc"));
    const snap = await getDocs(q);
    setMatches(snap.docs.map(d => ({ id:d.id, ...d.data() })));
    setLoading(false);
  };

  useEffect(() => { fetchMatches(); }, []);

  const filtered = filter === "সব" ? matches : matches.filter(m => m.mode === filter);

  return (
    <div style={{ padding:"16px 18px" }}>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:16 }}>
        <div>
          <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:16, fontWeight:700 }}>ম্যাচ সমূহ</div>
          <div style={{ fontSize:12, color:"rgba(255,255,255,0.4)", marginTop:2 }}>{matches.length}টি ম্যাচ পাওয়া গেছে</div>
        </div>
        <button onClick={fetchMatches} style={{ background:"rgba(255,255,255,0.07)", border:"1px solid rgba(255,255,255,0.1)", borderRadius:10, width:36, height:36, color:"#fff", cursor:"pointer", fontSize:16 }}>↻</button>
      </div>

      {/* FILTER */}
      <div style={{ display:"flex", gap:8, overflowX:"auto", paddingBottom:8, marginBottom:16 }}>
        {modes.map(m => (
          <button key={m} onClick={()=>setFilter(m)} style={{ background: filter===m ? "linear-gradient(135deg,#7c3aed,#a78bfa)" : "rgba(255,255,255,0.07)", border: filter===m ? "none" : "1px solid rgba(255,255,255,0.1)", borderRadius:20, padding:"7px 14px", color:"#fff", fontSize:11, fontFamily:"Orbitron,sans-serif", fontWeight:700, cursor:"pointer", whiteSpace:"nowrap", boxShadow: filter===m ? "0 4px 14px rgba(124,58,237,0.35)" : "none" }}>
            {m}
          </button>
        ))}
      </div>

      {loading ? (
        <div style={{ textAlign:"center", padding:40, color:"rgba(255,255,255,0.4)" }}>লোড হচ্ছে...</div>
      ) : filtered.length === 0 ? (
        <div style={{ background:"rgba(103,232,249,0.08)", border:"1px solid rgba(103,232,249,0.2)", borderRadius:12, padding:20, textAlign:"center", color:"#67e8f9", fontSize:13 }}>কোনো ম্যাচ পাওয়া যায়নি। পরে আবার চেষ্টা করুন!</div>
      ) : filtered.map(m => (
        <MatchCard key={m.id} match={m} onClick={()=>onMatchClick(m)} />
      ))}
    </div>
  );
}

function MatchCard({ match: m, onClick }) {
  const [timeLeft, setTimeLeft] = useState("");

  useEffect(() => {
    if (!m.scheduledAt) return;
    const interval = setInterval(() => {
      const diff = new Date(m.scheduledAt) - new Date();
      if (diff <= 0) { setTimeLeft("শুরু হয়েছে"); clearInterval(interval); return; }
      const h = Math.floor(diff/3600000);
      const min = Math.floor((diff%3600000)/60000);
      const sec = Math.floor((diff%60000)/1000);
      setTimeLeft(`${h}h ${min}m ${sec}s`);
    }, 1000);
    return ()=>clearInterval(interval);
  }, [m.scheduledAt]);

  return (
    <div onClick={onClick} style={{ background:"rgba(255,255,255,0.06)", border:"1.5px solid rgba(255,255,255,0.08)", borderRadius:16, padding:16, marginBottom:14, cursor:"pointer", transition:"all 0.2s" }}
      onMouseEnter={e=>{e.currentTarget.style.borderColor="rgba(167,139,250,0.4)";e.currentTarget.style.background="rgba(255,255,255,0.09)"}}
      onMouseLeave={e=>{e.currentTarget.style.borderColor="rgba(255,255,255,0.08)";e.currentTarget.style.background="rgba(255,255,255,0.06)"}}>
      
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:10 }}>
        <div style={{ flex:1 }}>
          <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:13, fontWeight:700, marginBottom:6, lineHeight:1.3 }}>{m.title}</div>
          <div style={{ display:"inline-block", background:"rgba(167,139,250,0.15)", color:"#c4b5fd", borderRadius:6, fontSize:10, fontFamily:"Orbitron,sans-serif", fontWeight:700, padding:"2px 8px" }}>ID: {m.id?.slice(-6).toUpperCase()}</div>
        </div>
        <div style={{ width:56, height:56, borderRadius:12, background:"rgba(255,255,255,0.05)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:28, marginLeft:12, flexShrink:0 }}>
          {m.mode === "BR Match" ? "🔫" : m.mode === "Clash Squad" ? "⚔️" : m.mode === "2V2" ? "🤝" : "🐺"}
        </div>
      </div>

      <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)", marginBottom:4 }}>🎮 {m.mode || "Squad"} · 📱 Mobile · 🗺️ {m.map || "Bermuda"}</div>
      <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)", marginBottom:4 }}>💵 প্রবেশ মূল্য: {m.entryFee || 0} BDT</div>
      <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)", marginBottom:4 }}>🏆 পুরস্কার: {m.prize || 0} BDT</div>
      {m.scheduledAt && <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)", marginBottom:10 }}>🕐 {new Date(m.scheduledAt).toLocaleString("bn-BD")}</div>}

      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:10 }}>
        <div style={{ background:"rgba(124,58,237,0.25)", color:"#c4b5fd", borderRadius:20, fontSize:11, fontFamily:"Orbitron,sans-serif", fontWeight:700, padding:"4px 12px" }}>
          {m.players || 0}/{m.maxPlayers || 0} Players
        </div>
        <div style={{ background: m.status==="live" ? "rgba(74,222,128,0.15)" : "rgba(103,232,249,0.15)", color: m.status==="live" ? "#4ade80" : "#67e8f9", border:`1px solid ${m.status==="live" ? "rgba(74,222,128,0.3)" : "rgba(103,232,249,0.3)"}`, borderRadius:20, fontSize:10, fontFamily:"Orbitron,sans-serif", fontWeight:700, padding:"4px 12px" }}>
          {m.status === "live" ? "● LIVE" : "UPCOMING"}
        </div>
      </div>

      <div style={{ display:"flex", gap:8 }}>
        <button onClick={e=>{e.stopPropagation();onClick();}} style={{ flex:1, background:"rgba(255,255,255,0.07)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:10, padding:"9px 0", color:"#c4b5fd", fontSize:11, fontFamily:"Orbitron,sans-serif", fontWeight:700, cursor:"pointer" }}>🏆 Prize Pool</button>
        <button onClick={e=>{e.stopPropagation();onClick();}} style={{ flex:1, background:"linear-gradient(135deg,#7c3aed,#a78bfa)", border:"none", borderRadius:10, padding:"9px 0", color:"#fff", fontSize:11, fontFamily:"Orbitron,sans-serif", fontWeight:700, cursor:"pointer", boxShadow:"0 4px 14px rgba(124,58,237,0.35)" }}>যোগ দিন →</button>
      </div>

      {timeLeft && (
        <div style={{ marginTop:10, background:"rgba(167,139,250,0.08)", border:"1px solid rgba(167,139,250,0.15)", borderRadius:10, padding:"8px 0", textAlign:"center", color:"#a78bfa", fontSize:12, fontFamily:"Orbitron,sans-serif", fontWeight:700 }}>
          ⏱ {timeLeft}
        </div>
      )}
    </div>
  );
}
