import { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { db } from "../firebase/config";
import { collection, query, orderBy, getDocs, doc, updateDoc } from "firebase/firestore";

/* ───────── RESULTS PAGE ───────── */
export function ResultsPage() {
  const [results, setResults] = useState([]);

  useEffect(() => {
    const fetch = async () => {
      const q = query(collection(db, "results"), orderBy("createdAt","desc"));
      const snap = await getDocs(q);
      setResults(snap.docs.map(d => ({ id:d.id, ...d.data() })));
    };
    fetch();
  }, []);

  return (
    <div style={{ padding:"16px 18px" }}>
      <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:16, fontWeight:700, marginBottom:16, display:"flex", alignItems:"center", gap:8 }}>🏆 ফলাফল</div>
      {results.length === 0 ? (
        <div style={{ background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:14, padding:40, textAlign:"center" }}>
          <div style={{ fontSize:36, marginBottom:12 }}>🏆</div>
          <div style={{ color:"rgba(255,255,255,0.4)", fontSize:13 }}>কোনো ফলাফল প্রকাশিত হয়নি</div>
        </div>
      ) : results.map(r => (
        <div key={r.id} style={{ background:"rgba(255,255,255,0.06)", border:"1.5px solid rgba(255,255,255,0.08)", borderRadius:16, padding:16, marginBottom:14 }}>
          <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:13, fontWeight:700, marginBottom:8 }}>{r.matchTitle}</div>
          <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)", marginBottom:12 }}>{new Date(r.createdAt).toLocaleDateString("bn-BD")}</div>
          {(r.winners || []).map((w, i) => (
            <div key={i} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"8px 0", borderBottom:"1px solid rgba(255,255,255,0.05)" }}>
              <span style={{ fontSize:13 }}>{i===0?"🥇":i===1?"🥈":i===2?"🥉":"🎖️"} {w.name}</span>
              <span style={{ fontFamily:"Orbitron,sans-serif", fontSize:13, fontWeight:700, color:"#4ade80" }}>৳{w.prize}</span>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

/* ───────── PROFILE PAGE ───────── */
export function ProfilePage() {
  const { user, userData, logout } = useAuth();
  const [showEdit, setShowEdit] = useState(false);
  const [editName, setEditName] = useState("");
  const [editUID, setEditUID] = useState("");
  const [editPhone, setEditPhone] = useState("");
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState("");

  const menuItems = [
    { icon:"📖", label:"নিয়মাবলী", color:"#a78bfa" },
    { icon:"👑", label:"শীর্ষ খেলোয়াড়", color:"#fbbf24" },
    { icon:"🎧", label:"সাপোর্ট", color:"#4ade80" },
    { icon:"💎", label:"Diamond Topup", color:"#67e8f9" },
    { icon:"👨‍💻", label:"Developer Info", color:"#c4b5fd" },
  ];

  const openEdit = () => {
    setEditName(userData?.name || "");
    setEditUID(userData?.ffUID || "");
    setEditPhone(userData?.phone || "");
    setSaveMsg("");
    setShowEdit(true);
  };

  const handleSave = async () => {
    if (!editName.trim()) { setSaveMsg("নাম খালি রাখা যাবে না"); return; }
    setSaving(true);
    try {
      await updateDoc(doc(db, "users", user.uid), {
        name: editName.trim(),
        ffUID: editUID.trim(),
        phone: editPhone.trim(),
      });
      userData.name = editName.trim();
      userData.ffUID = editUID.trim();
      userData.phone = editPhone.trim();
      setSaveMsg("✅ সফলভাবে সেভ হয়েছে!");
      setTimeout(() => setShowEdit(false), 1200);
    } catch(e) {
      setSaveMsg("কিছু সমস্যা হয়েছে, আবার চেষ্টা করুন");
    }
    setSaving(false);
  };

  const winRate = userData?.matches > 0
    ? Math.round((userData.wins / userData.matches) * 100)
    : 0;

  return (
    <div style={{ paddingBottom:20 }}>
      {/* COVER */}
      <div style={{ background:"linear-gradient(135deg,#4c1d95,#7c3aed,#6d28d9)", height:130, position:"relative", marginBottom:52 }}>
        <div style={{ position:"absolute", inset:0, opacity:0.15, backgroundImage:"radial-gradient(circle at 30% 50%, #fff 0%, transparent 50%)" }}></div>
        <div style={{ position:"absolute", top:8, right:12, background:"rgba(0,0,0,0.3)", borderRadius:8, padding:"3px 10px", fontSize:10, fontFamily:"Orbitron,sans-serif", color:"rgba(255,255,255,0.6)" }}>
          {userData?.ffUID ? `🎮 UID: ${userData.ffUID}` : "🎮 FF UID সেট করুন"}
        </div>
        <div style={{ position:"absolute", bottom:-44, left:"50%", transform:"translateX(-50%)" }}>
          <div style={{ width:88, height:88, borderRadius:22, background:"linear-gradient(135deg,#7c3aed,#c4b5fd)", display:"flex", alignItems:"center", justifyContent:"center", fontWeight:900, fontSize:36, fontFamily:"Orbitron,sans-serif", border:"3px solid #0a0118", boxShadow:"0 8px 24px rgba(124,58,237,0.5)" }}>
            {(userData?.name || "P")[0].toUpperCase()}
          </div>
        </div>
      </div>

      <div style={{ padding:"0 18px" }}>
        {/* NAME */}
        <div style={{ textAlign:"center", marginBottom:18 }}>
          <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:18, fontWeight:700, marginBottom:4 }}>{userData?.name || "Player"}</div>
          <div style={{ color:"rgba(255,255,255,0.4)", fontSize:12, marginBottom:4 }}>@{(userData?.name || "player").toLowerCase().replace(/ /g,"_")}</div>
          {userData?.email && <div style={{ color:"rgba(255,255,255,0.35)", fontSize:12 }}>✉️ {userData.email}</div>}
          {userData?.phone && <div style={{ color:"rgba(255,255,255,0.3)", fontSize:12, marginTop:2 }}>📱 {userData.phone}</div>}
        </div>

        {/* ACTION BUTTONS */}
        <div style={{ display:"flex", gap:10, marginBottom:20 }}>
          <button onClick={openEdit} style={{ flex:1, background:"rgba(167,139,250,0.1)", border:"1.5px solid rgba(167,139,250,0.25)", borderRadius:12, padding:"10px 0", color:"#c4b5fd", fontSize:12, fontFamily:"Orbitron,sans-serif", fontWeight:700, cursor:"pointer" }}>✏️ তথ্য সম্পাদনা</button>
          <button style={{ flex:1, background:"rgba(255,255,255,0.06)", border:"1.5px solid rgba(255,255,255,0.1)", borderRadius:12, padding:"10px 0", color:"#fff", fontSize:12, fontFamily:"Orbitron,sans-serif", fontWeight:700, cursor:"pointer" }}>🔑 পাসওয়ার্ড</button>
        </div>

        {/* STATS */}
        <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:8, marginBottom:20 }}>
          {[
            ["ম্যাচ", userData?.matches || 0, "#c4b5fd"],
            ["জয়", userData?.wins || 0, "#4ade80"],
            ["Win%", `${winRate}%`, "#fbbf24"],
            ["BDT", `৳${(userData?.wallet || 0).toFixed(0)}`, "#67e8f9"],
          ].map(([l,v,c]) => (
            <div key={l} style={{ background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:14, padding:"12px 4px", textAlign:"center" }}>
              <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:14, fontWeight:700, color:c }}>{v}</div>
              <div style={{ fontSize:10, color:"rgba(255,255,255,0.38)", marginTop:3 }}>{l}</div>
            </div>
          ))}
        </div>

        {/* MENU */}
        <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:16, overflow:"hidden", marginBottom:14 }}>
          {menuItems.map((item, i) => (
            <div key={i}
              style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"14px 16px", borderBottom: i < menuItems.length-1 ? "1px solid rgba(255,255,255,0.05)" : "none", cursor:"pointer", transition:"background 0.15s" }}
              onMouseEnter={e=>e.currentTarget.style.background="rgba(255,255,255,0.04)"}
              onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
              <div style={{ display:"flex", alignItems:"center", gap:12 }}>
                <span style={{ fontSize:18 }}>{item.icon}</span>
                <span style={{ fontSize:14, color:"rgba(255,255,255,0.8)" }}>{item.label}</span>
              </div>
              <span style={{ color:"rgba(255,255,255,0.25)", fontSize:16 }}>›</span>
            </div>
          ))}
        </div>

        <button onClick={logout} style={{ width:"100%", background:"rgba(248,113,113,0.1)", border:"1.5px solid rgba(248,113,113,0.25)", borderRadius:14, padding:"13px 0", color:"#f87171", fontFamily:"Orbitron,sans-serif", fontWeight:700, fontSize:12, cursor:"pointer", letterSpacing:1 }}>
          🚪 লগআউট
        </button>
      </div>

      {/* EDIT MODAL */}
      {showEdit && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.75)", backdropFilter:"blur(8px)", display:"flex", alignItems:"flex-end", justifyContent:"center", zIndex:300 }}>
          <div style={{ background:"#130d2e", border:"1.5px solid rgba(167,139,250,0.2)", borderRadius:"20px 20px 0 0", padding:24, width:"100%", maxWidth:480 }}>
            <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:20 }}>
              <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:14, fontWeight:700 }}>✏️ প্রোফাইল সম্পাদনা</div>
              <button onClick={()=>setShowEdit(false)} style={{ background:"rgba(255,255,255,0.08)", border:"none", color:"#fff", width:30, height:30, borderRadius:8, cursor:"pointer", fontSize:16 }}>✕</button>
            </div>

            <label style={{ fontSize:11, color:"rgba(255,255,255,0.45)", fontFamily:"Orbitron,sans-serif", letterSpacing:1, display:"block", marginBottom:6 }}>আপনার নাম</label>
            <input value={editName} onChange={e=>setEditName(e.target.value)} placeholder="নাম লিখুন"
              style={{ width:"100%", background:"rgba(255,255,255,0.07)", border:"1.5px solid rgba(255,255,255,0.12)", borderRadius:12, padding:"11px 14px", color:"#fff", fontSize:13, outline:"none", marginBottom:14, boxSizing:"border-box" }} />

            <label style={{ fontSize:11, color:"rgba(255,255,255,0.45)", fontFamily:"Orbitron,sans-serif", letterSpacing:1, display:"block", marginBottom:6 }}>Free Fire UID</label>
            <input value={editUID} onChange={e=>setEditUID(e.target.value)} placeholder="আপনার FF UID (ঐচ্ছিক)" type="number"
              style={{ width:"100%", background:"rgba(255,255,255,0.07)", border:"1.5px solid rgba(255,255,255,0.12)", borderRadius:12, padding:"11px 14px", color:"#fff", fontSize:13, outline:"none", marginBottom:14, boxSizing:"border-box" }} />

            <label style={{ fontSize:11, color:"rgba(255,255,255,0.45)", fontFamily:"Orbitron,sans-serif", letterSpacing:1, display:"block", marginBottom:6 }}>ফোন নম্বর</label>
            <input value={editPhone} onChange={e=>setEditPhone(e.target.value)} placeholder="01XXXXXXXXX (ঐচ্ছিক)"
              style={{ width:"100%", background:"rgba(255,255,255,0.07)", border:"1.5px solid rgba(255,255,255,0.12)", borderRadius:12, padding:"11px 14px", color:"#fff", fontSize:13, outline:"none", marginBottom:16, boxSizing:"border-box" }} />

            {saveMsg && (
              <div style={{ background: saveMsg.startsWith("✅") ? "rgba(74,222,128,0.12)" : "rgba(248,113,113,0.12)", border:`1px solid ${saveMsg.startsWith("✅") ? "rgba(74,222,128,0.3)" : "rgba(248,113,113,0.3)"}`, color: saveMsg.startsWith("✅") ? "#4ade80" : "#f87171", borderRadius:10, padding:"10px 14px", fontSize:12, marginBottom:14, textAlign:"center" }}>{saveMsg}</div>
            )}

            <div style={{ display:"flex", gap:10 }}>
              <button onClick={()=>setShowEdit(false)} style={{ flex:1, background:"rgba(255,255,255,0.08)", border:"none", borderRadius:12, padding:"12px 0", color:"#fff", fontFamily:"Orbitron,sans-serif", fontSize:11, cursor:"pointer" }}>বাতিল</button>
              <button onClick={handleSave} disabled={saving} style={{ flex:2, background:"linear-gradient(135deg,#7c3aed,#a78bfa)", border:"none", borderRadius:12, padding:"12px 0", color:"#fff", fontFamily:"Orbitron,sans-serif", fontSize:11, fontWeight:700, cursor:"pointer", boxShadow:"0 4px 16px rgba(124,58,237,0.4)", opacity: saving ? 0.7 : 1 }}>
                {saving ? "সেভ হচ্ছে..." : "💾 সেভ করুন"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
