import { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { db } from "../firebase/config";
import { doc, updateDoc, arrayUnion, getDoc } from "firebase/firestore";

export default function MatchDetailPage({ match: m, onBack }) {
  const { user, userData } = useAuth();
  const [showJoin, setShowJoin] = useState(false);
  const [showPrize, setShowPrize] = useState(false);
  const [playerName, setPlayerName] = useState("");
  const [timeLeft, setTimeLeft] = useState("");
  const [joining, setJoining] = useState(false);
  const [joined, setJoined] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    if (!m?.scheduledAt) return;
    const interval = setInterval(() => {
      const diff = new Date(m.scheduledAt) - new Date();
      if (diff <= 0) { setTimeLeft("শুরু হয়েছে!"); clearInterval(interval); return; }
      const h = Math.floor(diff/3600000);
      const min = Math.floor((diff%3600000)/60000);
      const sec = Math.floor((diff%60000)/1000);
      setTimeLeft(`${h}h ${min}m ${sec}s`);
    }, 1000);
    return () => clearInterval(interval);
  }, [m?.scheduledAt]);

  if (!m) return null;

  const slotsLeft = (m.maxPlayers || 0) - (m.players || 0);

  const handleJoin = async () => {
    if (!playerName.trim()) { setMsg("ইন-গেম নাম দিন"); return; }
    if ((userData?.wallet || 0) < (m.entryFee || 0)) { setMsg("ওয়ালেটে পর্যাপ্ত ব্যালেন্স নেই"); return; }
    setJoining(true);
    try {
      await updateDoc(doc(db, "matches", m.id), {
        participants: arrayUnion({ uid: user.uid, name: userData?.name, ingameName: playerName }),
        players: (m.players || 0) + 1
      });
      await updateDoc(doc(db, "users", user.uid), { wallet: (userData?.wallet || 0) - (m.entryFee || 0) });
      setJoined(true);
      setShowJoin(false);
      setMsg("✅ সফলভাবে যোগ দিয়েছেন!");
    } catch(e) { setMsg("কিছু সমস্যা হয়েছে"); }
    setJoining(false);
  };

  return (
    <div style={{ padding:"16px 18px" }}>
      {/* HEADER BANNER */}
      <div style={{ background:"linear-gradient(135deg,#1e3a8a,#4c1d95)", borderRadius:18, padding:18, marginBottom:16, position:"relative", overflow:"hidden", border:"1.5px solid rgba(167,139,250,0.15)" }}>
        <div style={{ position:"absolute", top:0, right:0, bottom:0, width:"40%", opacity:0.15, display:"flex", alignItems:"center", justifyContent:"center", fontSize:70 }}>🎮</div>
        <div style={{ display:"flex", gap:8, flexWrap:"wrap", marginBottom:10 }}>
          <span style={{ background:"rgba(74,222,128,0.2)", color:"#4ade80", border:"1px solid rgba(74,222,128,0.3)", fontSize:10, fontFamily:"Orbitron,sans-serif", fontWeight:700, padding:"3px 10px", borderRadius:20 }}>UPCOMING</span>
          <span style={{ background:"rgba(255,255,255,0.1)", color:"rgba(255,255,255,0.7)", fontSize:10, fontFamily:"Orbitron,sans-serif", padding:"3px 10px", borderRadius:20 }}>ID: {m.id?.slice(-6).toUpperCase()}</span>
          <span style={{ background:"rgba(255,255,255,0.08)", color:"rgba(255,255,255,0.6)", fontSize:10, fontFamily:"Orbitron,sans-serif", padding:"3px 10px", borderRadius:20 }}>🎮 {m.mode} · Mobile</span>
        </div>
        <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:16, fontWeight:700, lineHeight:1.3, marginBottom:6 }}>{m.title}</div>
        {m.scheduledAt && <div style={{ fontSize:11, color:"rgba(255,255,255,0.5)" }}>🕐 {new Date(m.scheduledAt).toLocaleString("bn-BD")}</div>}
      </div>

      {/* STATS */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:8, marginBottom:14 }}>
        {[["প্রবেশ মূল্য", `৳${m.entryFee || 0}`, "#c4b5fd"], ["পুরস্কার", `৳${m.prize || 0}`, "#fbbf24"], ["খেলোয়াড়", `${m.players || 0}/${m.maxPlayers || 0}`, "#fff"], ["স্লট বাকি", slotsLeft, "#4ade80"]].map(([l,v,c]) => (
          <div key={l} style={{ background:"rgba(255,255,255,0.06)", borderRadius:12, padding:"12px 8px", textAlign:"center", border:"1px solid rgba(255,255,255,0.07)" }}>
            <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:14, fontWeight:700, color:c }}>{v}</div>
            <div style={{ fontSize:9, color:"rgba(255,255,255,0.4)", textTransform:"uppercase", marginTop:3, letterSpacing:0.5 }}>{l}</div>
          </div>
        ))}
      </div>

      {/* PROGRESS */}
      <div style={{ background:"rgba(255,255,255,0.06)", borderRadius:10, height:6, marginBottom:14, overflow:"hidden" }}>
        <div style={{ height:"100%", width:`${((m.players||0)/(m.maxPlayers||1))*100}%`, background:"linear-gradient(90deg,#7c3aed,#a78bfa)", borderRadius:10, transition:"width 0.5s" }}></div>
      </div>

      {/* COUNTDOWN */}
      {timeLeft && (
        <div style={{ background:"rgba(167,139,250,0.08)", border:"1px solid rgba(167,139,250,0.2)", borderRadius:14, padding:"14px 0", textAlign:"center", color:"#a78bfa", fontFamily:"Orbitron,sans-serif", fontWeight:700, fontSize:18, marginBottom:14, letterSpacing:2 }}>
          ⏱ {timeLeft}
        </div>
      )}

      {msg && <div style={{ background: msg.startsWith("✅") ? "rgba(74,222,128,0.12)" : "rgba(248,113,113,0.12)", border:`1px solid ${msg.startsWith("✅") ? "rgba(74,222,128,0.3)" : "rgba(248,113,113,0.3)"}`, color: msg.startsWith("✅") ? "#4ade80" : "#f87171", borderRadius:10, padding:"10px 14px", textAlign:"center", fontSize:12, marginBottom:14 }}>{msg}</div>}

      {/* PRIZE DISTRIBUTION */}
      <div style={{ background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:14, padding:16, marginBottom:12 }}>
        <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:12, fontWeight:700, marginBottom:12, display:"flex", alignItems:"center", gap:8 }}>🏆 পুরস্কার বিতরণ</div>
        {(m.prizes || [{ place:"১ম", amount: m.prize }]).map((p, i) => (
          <div key={i} style={{ display:"flex", justifyContent:"space-between", padding:"8px 0", borderBottom:"1px solid rgba(255,255,255,0.05)" }}>
            <span style={{ fontSize:13 }}>{i===0?"🥇":i===1?"🥈":i===2?"🥉":"🎖️"} {p.place || `${i+1}st Place`}</span>
            <span style={{ fontFamily:"Orbitron,sans-serif", fontSize:13, fontWeight:700, color:"#4ade80" }}>৳{p.amount} BDT</span>
          </div>
        ))}
        {m.perKill && (
          <div style={{ display:"flex", justifyContent:"space-between", padding:"8px 0" }}>
            <span style={{ fontSize:13 }}>⚔️ প্রতি কিল</span>
            <span style={{ fontFamily:"Orbitron,sans-serif", fontSize:13, fontWeight:700, color:"#67e8f9" }}>৳{m.perKill} BDT</span>
          </div>
        )}
      </div>

      {/* RULES */}
      <div style={{ background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:14, padding:16, marginBottom:12 }}>
        <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:12, fontWeight:700, marginBottom:10, display:"flex", alignItems:"center", gap:8 }}>📋 নিয়মাবলী</div>
        <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)", lineHeight:1.8 }}>
          {m.rules || "১. অ্যান্টি-চিট ব্যবহার করা যাবে না\n২. ম্যাচ শুরুর ৫ মিনিট আগে রেডি থাকতে হবে\n৩. রুম আইডি ও পাসওয়ার্ড সময়মতো দেওয়া হবে\n৪. ফলাফল স্ক্রিনশট দিয়ে সাবমিট করতে হবে"}
        </div>
      </div>

      {/* PARTICIPANTS */}
      <div style={{ background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:14, padding:16, marginBottom:20 }}>
        <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:12, fontWeight:700, marginBottom:10 }}>👥 অংশগ্রহণকারী</div>
        {(m.participants || []).length === 0 ? (
          <div style={{ color:"rgba(255,255,255,0.35)", fontSize:12, textAlign:"center", padding:"10px 0" }}>এখনো কেউ যোগ দেয়নি</div>
        ) : (m.participants||[]).map((p,i) => (
          <div key={i} style={{ display:"flex", alignItems:"center", gap:10, padding:"7px 0", borderBottom:"1px solid rgba(255,255,255,0.05)" }}>
            <div style={{ width:28, height:28, borderRadius:8, background:"linear-gradient(135deg,#7c3aed,#a78bfa)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:12, fontWeight:700 }}>{(p.ingameName||p.name||"P")[0]}</div>
            <div style={{ fontSize:12, fontWeight:500 }}>{p.ingameName || p.name}</div>
          </div>
        ))}
      </div>

      {/* JOIN BUTTON */}
      {!joined && slotsLeft > 0 && (
        <button onClick={()=>setShowJoin(true)} style={{ width:"100%", background:"linear-gradient(135deg,#7c3aed,#a78bfa)", color:"#fff", border:"none", borderRadius:14, padding:"14px 0", fontFamily:"Orbitron,sans-serif", fontWeight:700, fontSize:13, cursor:"pointer", boxShadow:"0 6px 22px rgba(124,58,237,0.45)", letterSpacing:1 }}>
          যোগ দিন → (প্রবেশ মূল্য: ৳{m.entryFee || 0})
        </button>
      )}

      {/* JOIN MODAL */}
      {showJoin && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.7)", backdropFilter:"blur(8px)", display:"flex", alignItems:"flex-end", justifyContent:"center", zIndex:200, padding:18 }}>
          <div style={{ background:"#130d2e", border:"1.5px solid rgba(167,139,250,0.2)", borderRadius:"20px 20px 0 0", padding:24, width:"100%", maxWidth:480 }}>
            <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:14, fontWeight:700, marginBottom:6, display:"flex", alignItems:"center", gap:8 }}>👤 ম্যাচে যোগ দিন</div>
            <div style={{ fontSize:12, color:"rgba(255,255,255,0.4)", marginBottom:16 }}>{m.title} · {m.mode} · {slotsLeft}টি স্লট বাকি</div>
            <div style={{ display:"flex", gap:8, marginBottom:14 }}>
              {["Team 1","Team 2"].map((t,i) => (
                <div key={i} style={{ flex:1, background:"rgba(167,139,250,0.08)", border:"1.5px solid rgba(167,139,250,0.25)", borderRadius:12, padding:"10px 14px", display:"flex", justifyContent:"space-between", cursor:"pointer" }}>
                  <span style={{ fontSize:13 }}>👥 {t}</span>
                  <span style={{ fontSize:11, color:"#4ade80" }}>4 Slots</span>
                </div>
              ))}
            </div>
            <div style={{ display:"flex", gap:8, marginBottom:14 }}>
              <input value={playerName} onChange={e=>setPlayerName(e.target.value)} placeholder="ইন-গেম নাম লিখুন" style={{ flex:1, background:"rgba(255,255,255,0.07)", border:"1.5px solid rgba(255,255,255,0.1)", borderRadius:12, padding:"11px 14px", color:"#fff", fontSize:13, outline:"none" }} />
            </div>
            <div style={{ background:"rgba(251,191,36,0.1)", border:"1px solid rgba(251,191,36,0.25)", borderRadius:10, padding:"10px 14px", fontSize:12, color:"#fbbf24", marginBottom:16 }}>
              প্রবেশ মূল্য: ৳{m.entryFee} · আপনার ব্যালেন্স: ৳{userData?.wallet?.toFixed(2) || "0.00"}
            </div>
            {msg && <div style={{ color:"#f87171", fontSize:12, marginBottom:10, textAlign:"center" }}>{msg}</div>}
            <div style={{ display:"flex", gap:10 }}>
              <button onClick={()=>setShowJoin(false)} style={{ flex:1, background:"rgba(255,255,255,0.08)", border:"1px solid rgba(255,255,255,0.1)", borderRadius:12, padding:"12px 0", color:"#fff", fontFamily:"Orbitron,sans-serif", fontSize:11, cursor:"pointer" }}>বাতিল</button>
              <button onClick={handleJoin} disabled={joining} style={{ flex:2, background:"linear-gradient(135deg,#7c3aed,#a78bfa)", border:"none", borderRadius:12, padding:"12px 0", color:"#fff", fontFamily:"Orbitron,sans-serif", fontSize:11, fontWeight:700, cursor:"pointer", boxShadow:"0 4px 16px rgba(124,58,237,0.4)" }}>
                {joining ? "যোগ হচ্ছে..." : "✅ এখনই যোগ দিন"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
