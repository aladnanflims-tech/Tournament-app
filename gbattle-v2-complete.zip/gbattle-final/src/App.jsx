import { useState } from "react";
import { AuthProvider, useAuth } from "./context/AuthContext";
import LoginPage from "./pages/LoginPage";
import HomePage from "./pages/HomePage";
import MatchesPage from "./pages/MatchesPage";
import WalletPage from "./pages/WalletPage";
import { ResultsPage, ProfilePage } from "./pages/OtherPages";
import MatchDetailPage from "./pages/MatchDetailPage";
import AdminPage from "./pages/AdminPage";
import BottomNav from "./components/BottomNav";
import Topbar from "./components/Topbar";

// Admin UID list — add your Firebase UID here
const ADMIN_UIDS = ["ADMIN_UID_1", "ADMIN_UID_2"];

function AppInner() {
  const { user, userData, loading } = useAuth();
  const [page, setPage] = useState("home");
  const [selectedMatch, setSelectedMatch] = useState(null);
  const [showAdmin, setShowAdmin] = useState(false);

  if (loading) return (
    <div style={{ display:"flex", alignItems:"center", justifyContent:"center", height:"100vh", background:"#0a0118" }}>
      <div style={{ textAlign:"center" }}>
        <div style={{ fontFamily:"Orbitron,sans-serif", fontSize:28, fontWeight:900, background:"linear-gradient(90deg,#a78bfa,#fff)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent", marginBottom:16 }}>G-BATTLE</div>
        <div style={{ width:40, height:40, border:"3px solid rgba(167,139,250,0.3)", borderTop:"3px solid #a78bfa", borderRadius:"50%", animation:"spin 0.8s linear infinite", margin:"0 auto" }}></div>
      </div>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );

  if (!user) return <LoginPage />;

  // Admin panel (full screen override)
  if (showAdmin) return <AdminPage onBack={()=>setShowAdmin(false)} />;

  const goToMatch = (match) => { setSelectedMatch(match); setPage("matchdetail"); };
  const goBack = () => { setSelectedMatch(null); setPage("matches"); };
  const isAdmin = ADMIN_UIDS.includes(user.uid);

  return (
    <div style={{ background:"#0a0118", minHeight:"100vh", color:"#fff", fontFamily:"Inter,sans-serif", maxWidth:480, margin:"0 auto", position:"relative" }}>
      <Topbar page={page} onBack={goBack} isAdmin={isAdmin} onAdmin={()=>setShowAdmin(true)} />
      <div style={{ paddingBottom:70 }}>
        {page === "home" && <HomePage onNavigate={setPage} onMatchClick={goToMatch} />}
        {page === "matches" && <MatchesPage onMatchClick={goToMatch} />}
        {page === "wallet" && <WalletPage />}
        {page === "results" && <ResultsPage />}
        {page === "profile" && <ProfilePage />}
        {page === "matchdetail" && <MatchDetailPage match={selectedMatch} onBack={goBack} />}
      </div>
      {page !== "matchdetail" && <BottomNav page={page} setPage={setPage} />}
    </div>
  );
}

export default function App() {
  return <AuthProvider><AppInner /></AuthProvider>;
}
