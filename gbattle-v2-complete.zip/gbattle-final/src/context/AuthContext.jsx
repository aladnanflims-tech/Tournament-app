import { createContext, useContext, useEffect, useState } from "react";
import { auth, db } from "../firebase/config";
import {
  onAuthStateChanged,
  signInWithPopup,
  GoogleAuthProvider,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  RecaptchaVerifier,
  signInWithPhoneNumber
} from "firebase/auth";
import { doc, setDoc, getDoc } from "firebase/firestore";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        const snap = await getDoc(doc(db, "users", u.uid));
        if (snap.exists()) setUserData(snap.data());
        else {
          const data = {
            uid: u.uid,
            name: u.displayName || "Player",
            email: u.email || "",
            phone: u.phoneNumber || "",
            avatar: u.photoURL || "",
            wallet: 0,
            matches: 0,
            wins: 0,
            createdAt: new Date().toISOString()
          };
          await setDoc(doc(db, "users", u.uid), data);
          setUserData(data);
        }
      } else {
        setUserData(null);
      }
      setLoading(false);
    });
    return unsub;
  }, []);

  const loginGoogle = () => signInWithPopup(auth, new GoogleAuthProvider());

  const loginEmail = (email, pass) => signInWithEmailAndPassword(auth, email, pass);

  const registerEmail = async (email, pass, name) => {
    const cred = await createUserWithEmailAndPassword(auth, email, pass);
    await setDoc(doc(db, "users", cred.user.uid), {
      uid: cred.user.uid, name, email,
      wallet: 0, matches: 0, wins: 0,
      createdAt: new Date().toISOString()
    });
    return cred;
  };

  const setupRecaptcha = (elementId) => {
    window.recaptchaVerifier = new RecaptchaVerifier(auth, elementId, { size: "invisible" });
  };

  const sendOTP = (phone) => {
    const verifier = window.recaptchaVerifier;
    return signInWithPhoneNumber(auth, phone, verifier);
  };

  const logout = () => signOut(auth);

  return (
    <AuthContext.Provider value={{ user, userData, loading, loginGoogle, loginEmail, registerEmail, setupRecaptcha, sendOTP, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
