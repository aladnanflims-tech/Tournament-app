import { useAuth } from "../context/AuthContext";

export default function Topbar({ page, onBack, isAdmin, onAdmin }) {
  const { userData } = useAuth();

  if (page === "matchdetail") {
    return (
      <div style={{ display:"flex", alignItems:"center", padding:"12px 18px", background:"rgba(10,1,24,0.95)", backdropFilter:"blur(20px)", borderBottom:"1px solid rgba(255,255,255,0.07)", position:"sticky", top:0, zIndex:50 }}>
        <button onClick={onBack} style={{ background:"rgba(255,255,255,0.08)", border:"none", color:"#fff", width:34, height:34, borderRadius:10, cursor:"pointer", fontSize:18, display:"flex", alignItems:"center", justifyContent:"center", marginRight:12 }}>‹</button>
        <div style={{ fontFamily:"Orbitron,sans-serif", fontWeight:700, fontSize:14 }}>ম্যাচ বিবরণ</div>
      </div>
    );
  }

  return (
    <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"12px 18px", background:"rgba(10,1,24,0.95)", backdropFilter:"blur(20px)", borderBottom:"1px solid rgba(255,255,255,0.07)", position:"sticky", top:0, zIndex:50 }}>
      <div style={{ fontFamily:"Orbitron,sans-serif", fontWeight:900, fontSize:16, background:"linear-gradient(90deg,#a78bfa,#fff)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent", letterSpacing:2 }}>G-BATTLE</div>
      <div style={{ display:"flex", alignItems:"center", gap:8 }}>
        <div style={{ background:"rgba(167,139,250,0.15)", border:"1px solid rgba(167,139,250,0.25)", borderRadius:20, padding:"5px 12px", fontSize:12, fontWeight:600, color:"#c4b5fd" }}>
          💰 ৳{(userData?.wallet || 0).toFixed(2)}
        </div>
        {isAdmin && (
          <button onClick={onAdmin} style={{ background:"rgba(248,113,113,0.15)", border:"1px solid rgba(248,113,113,0.3)", color:"#f87171", borderRadius:10, padding:"5px 10px", fontSize:10, fontFamily:"Orbitron,sans-serif", fontWeight:700, cursor:"pointer", letterSpacing:0.5 }}>
            🔐 ADMIN
          </button>
        )}
        <div style={{ width:34, height:34, borderRadius:10, background:"linear-gradient(135deg,#7c3aed,#c4b5fd)", display:"flex", alignItems:"center", justifyContent:"center", fontWeight:700, fontSize:14, boxShadow:"0 0 12px rgba(124,58,237,0.4)" }}>
          {(userData?.name || "P")[0].toUpperCase()}
        </div>
      </div>
    </div>
  );
}
