const tabs = [
  { id:"home", label:"হোম", icon:"🏠" },
  { id:"matches", label:"ম্যাচ", icon:"🎮" },
  { id:"wallet", label:"ওয়ালেট", icon:"💰" },
  { id:"results", label:"ফলাফল", icon:"🏆" },
  { id:"profile", label:"প্রোফাইল", icon:"👤" },
];

export default function BottomNav({ page, setPage }) {
  return (
    <div style={{ position:"fixed", bottom:0, left:"50%", transform:"translateX(-50%)", width:"100%", maxWidth:480, background:"rgba(10,1,24,0.95)", backdropFilter:"blur(20px)", borderTop:"1px solid rgba(255,255,255,0.07)", display:"flex", zIndex:100, padding:"8px 0 10px" }}>
      {tabs.map(t => (
        <button key={t.id} onClick={() => setPage(t.id)}
          style={{ flex:1, background:"none", border:"none", cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:3, padding:"6px 0", transition:"all 0.2s" }}>
          <span style={{ fontSize:20, filter: page===t.id ? "drop-shadow(0 0 6px #a78bfa)" : "none" }}>{t.icon}</span>
          <span style={{ fontSize:10, fontFamily:"Orbitron,sans-serif", fontWeight:700, color: page===t.id ? "#a78bfa" : "rgba(255,255,255,0.35)", letterSpacing:0.5 }}>{t.label}</span>
          {page===t.id && <div style={{ width:16, height:2, background:"linear-gradient(90deg,#7c3aed,#a78bfa)", borderRadius:2, marginTop:1, boxShadow:"0 0 8px rgba(167,139,250,0.6)" }}></div>}
        </button>
      ))}
    </div>
  );
}
